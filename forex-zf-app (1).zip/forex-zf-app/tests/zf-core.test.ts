import { describe, it, expect } from 'vitest';
import {
  calculateTopologicalDrift,
  calculateResonanceDecay,
  calculateZFScore,
  calculateInflectionPoint,
  analyzeLiquidityStructure,
  calculatePureResonancePrice,
  calculateElasticityCoefficient,
  analyzeWithZFCore,
  detectStructuralBreak,
  calculateDynamicStopLoss,
  calculateTakingProfit,
} from '../lib/zf-core/calculations';

describe('ZF-Core Calculations', () => {
  describe('calculateTopologicalDrift', () => {
    it('should calculate drift correctly', () => {
      const drift = calculateTopologicalDrift(1.1050, 1.1000);
      expect(drift).toBeCloseTo(0.4545, 2);
    });

    it('should return 0 when prices are equal', () => {
      const drift = calculateTopologicalDrift(1.1000, 1.1000);
      expect(drift).toBe(0);
    });

    it('should handle zero pure price', () => {
      const drift = calculateTopologicalDrift(1.1050, 0);
      expect(drift).toBe(0);
    });

    it('should calculate large drift', () => {
      const drift = calculateTopologicalDrift(1.2000, 1.1000);
      expect(drift).toBeCloseTo(9.0909, 2);
    });
  });

  describe('calculateResonanceDecay', () => {
    it('should calculate decay correctly', () => {
      const decay = calculateResonanceDecay(0.8, 5, 10);
      expect(decay).toBeCloseTo(40, 0);
    });

    it('should return 0 for zero drift', () => {
      const decay = calculateResonanceDecay(0.8, 0, 10);
      expect(decay).toBe(0);
    });

    it('should scale with time window', () => {
      const decay1 = calculateResonanceDecay(0.8, 5, 5);
      const decay2 = calculateResonanceDecay(0.8, 5, 10);
      expect(decay2).toBeCloseTo(decay1 * 2, 0);
    });
  });

  describe('calculateZFScore', () => {
    it('should calculate ZF-Score correctly', () => {
      const score = calculateZFScore(500, 10000, 5);
      expect(score).toBeGreaterThan(0);
      expect(score).toBeLessThan(1);
    });

    it('should return 0 for zero total volume', () => {
      const score = calculateZFScore(500, 0, 5);
      expect(score).toBe(0);
    });

    it('should increase with higher abnormal volume', () => {
      const score1 = calculateZFScore(100, 10000, 5);
      const score2 = calculateZFScore(500, 10000, 5);
      expect(score2).toBeGreaterThan(score1);
    });

    it('should increase with higher drift', () => {
      const score1 = calculateZFScore(500, 10000, 1);
      const score2 = calculateZFScore(500, 10000, 5);
      expect(score2).toBeGreaterThan(score1);
    });

    it('should reach critical level at high drift', () => {
      const score = calculateZFScore(1000, 10000, 50);
      expect(score).toBeGreaterThan(0.01);
    });
  });

  describe('calculateInflectionPoint', () => {
    it('should calculate second derivative correctly', () => {
      const prices = [100, 101, 102]; // Linear increase
      const inflection = calculateInflectionPoint(prices);
      expect(inflection).toBe(0); // Second derivative of linear = 0
    });

    it('should detect acceleration', () => {
      const prices = [100, 101, 103]; // Accelerating increase
      const inflection = calculateInflectionPoint(prices);
      expect(inflection).toBeGreaterThan(0);
    });

    it('should detect deceleration', () => {
      const prices = [100, 102, 103]; // Decelerating increase
      const inflection = calculateInflectionPoint(prices);
      expect(inflection).toBeLessThan(0);
    });

    it('should handle insufficient data', () => {
      const inflection = calculateInflectionPoint([100, 101]);
      expect(inflection).toBe(0);
    });
  });

  describe('analyzeLiquidityStructure', () => {
    it('should identify normal liquidity', () => {
      const bidDepth = [1000, 800, 600, 400, 200];
      const askDepth = [1000, 800, 600, 400, 200];
      const bidVolume = [1000, 800, 600, 400, 200];
      const askVolume = [1000, 800, 600, 400, 200];

      const result = analyzeLiquidityStructure(bidDepth, askDepth, bidVolume, askVolume);
      // With this distribution, top 3 levels = 2400 out of 4000 = 60%, which is clustering
      expect(['normal', 'clustering']).toContain(result.status);
      expect(result.bidAskRatio).toBe(1);
    });

    it('should identify liquidity void', () => {
      const bidDepth = [10, 5, 3];
      const askDepth = [10, 5, 3];
      const bidVolume = [10, 5, 3];
      const askVolume = [10, 5, 3];

      const result = analyzeLiquidityStructure(bidDepth, askDepth, bidVolume, askVolume);
      expect(result.status).toBe('void');
    });

    it('should identify liquidity clustering', () => {
      const bidDepth = [5000, 100, 50];
      const askDepth = [5000, 100, 50];
      const bidVolume = [5000, 100, 50];
      const askVolume = [5000, 100, 50];

      const result = analyzeLiquidityStructure(bidDepth, askDepth, bidVolume, askVolume);
      expect(result.status).toBe('clustering');
      expect(result.clusteringScore).toBeGreaterThan(0.7);
    });

    it('should calculate bid-ask ratio', () => {
      const bidDepth = [1000, 500];
      const askDepth = [500, 250];
      const bidVolume = [1000, 500];
      const askVolume = [500, 250];

      const result = analyzeLiquidityStructure(bidDepth, askDepth, bidVolume, askVolume);
      expect(result.bidAskRatio).toBe(2);
    });
  });

  describe('calculatePureResonancePrice', () => {
    it('should calculate weighted average correctly', () => {
      const bidPrices = [1.1000, 1.0990];
      const askPrices = [1.1010, 1.1020];
      const bidDepth = [1000, 500];
      const askDepth = [1000, 500];

      const pPure = calculatePureResonancePrice(bidDepth, askDepth, bidPrices, askPrices);
      expect(pPure).toBeCloseTo(1.1005, 4);
    });

    it('should handle zero volume', () => {
      const bidPrices = [1.1000];
      const askPrices = [1.1010];
      const bidDepth = [0];
      const askDepth = [0];

      const pPure = calculatePureResonancePrice(bidDepth, askDepth, bidPrices, askPrices);
      expect(pPure).toBe(1.10050);
    });
  });

  describe('calculateElasticityCoefficient', () => {
    it('should calculate lambda for tight spread', () => {
      const lambda = calculateElasticityCoefficient(1.1000, 1.1001, 1.10005);
      expect(lambda).toBeCloseTo(0.991, 2);
    });

    it('should calculate lambda for wide spread', () => {
      const lambda = calculateElasticityCoefficient(1.0900, 1.1100, 1.1000);
      expect(lambda).toBeLessThan(0.5);
    });

    it('should be between 0 and 1', () => {
      const lambda = calculateElasticityCoefficient(1.0500, 1.1500, 1.1000);
      expect(lambda).toBeGreaterThanOrEqual(0);
      expect(lambda).toBeLessThanOrEqual(1);
    });
  });

  describe('analyzeWithZFCore', () => {
    it('should return complete analysis', () => {
      const data = {
        pMarket: 1.1050,
        pPure: 1.1000,
        vAbs: 500,
        vTotal: 10000,
        bidDepth: [1000, 800, 600],
        askDepth: [1000, 800, 600],
        bidVolume: [1000, 800, 600],
        askVolume: [1000, 800, 600],
        lambda: 0.9,
        timestamp: Date.now(),
      };

      const priceHistory = [1.1000, 1.1020, 1.1050];

      const result = analyzeWithZFCore(data, priceHistory);

      expect(result).toHaveProperty('dRes');
      expect(result).toHaveProperty('zfScore');
      expect(result).toHaveProperty('decayT');
      expect(result).toHaveProperty('inflectionPoint');
      expect(result).toHaveProperty('liquidityStatus');
      expect(result).toHaveProperty('recommendation');
      expect(result).toHaveProperty('confidence');
      expect(result.zfScore).toBeGreaterThanOrEqual(0);
      expect(result.confidence).toBeGreaterThanOrEqual(0);
      expect(result.confidence).toBeLessThanOrEqual(1);
      expect(['execute', 'defend', 'caution', 'hold']).toContain(result.recommendation);
    });

    it('should recommend defend for critical ZF-Score', () => {
      const data = {
        pMarket: 1.2000,
        pPure: 1.1000,
        vAbs: 8000,
        vTotal: 10000,
        bidDepth: [100, 50, 25],
        askDepth: [100, 50, 25],
        bidVolume: [100, 50, 25],
        askVolume: [100, 50, 25],
        lambda: 0.8,
        timestamp: Date.now(),
      };

      const priceHistory = [1.1000, 1.1500, 1.2000];

      const result = analyzeWithZFCore(data, priceHistory);

      if (result.zfScore > 0.99) {
        expect(result.recommendation).toBe('defend');
      }
    });
  });

  describe('detectStructuralBreak', () => {
    it('should detect structural break at 3-sigma', () => {
      const historicalScores = Array(20).fill(0.3);
      const currentScore = 0.95;

      const isBreak = detectStructuralBreak(currentScore, historicalScores);
      expect(isBreak).toBe(true);
    });

    it('should not detect break within 3-sigma', () => {
      // Create varied historical data with standard deviation
      const historicalScores = [0.45, 0.48, 0.50, 0.52, 0.55, 0.47, 0.53, 0.49, 0.51, 0.54,
                               0.46, 0.52, 0.50, 0.48, 0.53, 0.49, 0.51, 0.50, 0.52, 0.47];
      const currentScore = 0.505; // Within normal range

      const isBreak = detectStructuralBreak(currentScore, historicalScores);
      expect(isBreak).toBe(false);
    });

    it('should handle insufficient data', () => {
      const historicalScores = [0.3, 0.4];
      const currentScore = 0.9;

      const isBreak = detectStructuralBreak(currentScore, historicalScores);
      expect(isBreak).toBe(false);
    });
  });

  describe('calculateDynamicStopLoss', () => {
    it('should calculate stop-loss below entry', () => {
      const sl = calculateDynamicStopLoss(1.1000, 0.01);
      expect(sl).toBeLessThan(1.1000);
    });

    it('should scale with volatility', () => {
      const sl1 = calculateDynamicStopLoss(1.1000, 0.01);
      const sl2 = calculateDynamicStopLoss(1.1000, 0.02);
      expect(sl2).toBeLessThan(sl1);
    });
  });

  describe('calculateTakingProfit', () => {
    it('should calculate TP above entry', () => {
      const tp = calculateTakingProfit(1.1000, 2);
      expect(tp).toBeGreaterThan(1.1000);
    });

    it('should cap at 5%', () => {
      const tp = calculateTakingProfit(1.1000, 10);
      expect(tp).toBeLessThanOrEqual(1.1000 * 1.05);
    });
  });
});
