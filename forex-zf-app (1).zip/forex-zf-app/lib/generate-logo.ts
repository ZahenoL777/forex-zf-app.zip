/**
 * Logo generation helper
 * This file documents how to generate the app logo
 * 
 * In production, use the generate tool to create a custom icon
 * For now, we use a placeholder that should be replaced
 */

export const LOGO_SPECS = {
  name: 'Forex ZF-Core Analyzer',
  description: 'Professional Forex & BTC market analysis with ZF-Core algorithm',
  style: 'Modern, geometric, professional trading app',
  colors: {
    primary: '#0a7ea4',
    accent: '#22C55E',
    dark: '#151718',
  },
  requirements: {
    format: 'PNG with transparent background',
    sizes: [
      '1024x1024 (icon.png)',
      '1024x1024 (splash-icon.png)',
      '512x512 (favicon.png)',
      '1024x1024 (android-icon-foreground.png)',
    ],
    style: 'Iconic, simple, suitable for app launcher',
    elements: [
      'Chart/candlestick visualization',
      'ZF-Core concept (resonance/wave)',
      'Professional trading aesthetic',
    ],
  },
};

export const LOGO_GENERATION_PROMPT = `
Create a professional app icon for "Forex ZF-Core Analyzer" - a mobile app for real-time Forex and BTC market analysis.

Design Requirements:
- Square format (1024x1024px)
- Modern, geometric style
- Professional trading app aesthetic
- Primary color: #0a7ea4 (teal/blue)
- Accent color: #22C55E (green)
- Dark background: #151718

Visual Elements:
- Incorporate a candlestick chart or price wave visualization
- Include geometric shapes representing the ZF-Core resonance concept
- Use clean lines and minimalist design
- No rounded corners, fill entire square
- Should look professional in app launcher

Style: Similar to professional trading platforms like TradingView, MetaTrader, or Bloomberg Terminal
Mood: Trustworthy, analytical, precise, modern

Output: PNG with transparent background, suitable for iOS and Android app icons
`;
