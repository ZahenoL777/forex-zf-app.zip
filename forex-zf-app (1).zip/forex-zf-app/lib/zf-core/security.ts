/**
 * Security Layer for Forex ZF-Core Analyzer
 * 
 * Comprehensive security features:
 * - Anti-manipulation: Detect & reject tampered data
 * - Anti-blocking: Bypass network restrictions & proxies
 * - Data integrity: Cryptographic validation
 * - Anomaly detection: Identify suspicious patterns
 * - Secure communication: Encrypted channels
 * - Rate limiting: Prevent abuse & detection
 */

import * as crypto from 'crypto';

/**
 * Data integrity check result
 */
export interface IntegrityCheckResult {
  isValid: boolean;
  hash: string;
  timestamp: number;
  checksum: string;
  anomalies: string[];
}

/**
 * Network request configuration for anti-blocking
 */
export interface AntiBlockingConfig {
  useProxy: boolean;
  rotateUserAgent: boolean;
  randomizeHeaders: boolean;
  useVPN: boolean;
  delayRequest: number; // milliseconds
  retryCount: number;
}

/**
 * Security Service
 */
export class SecurityService {
  private dataHashes: Map<string, string> = new Map();
  private requestTimestamps: Map<string, number[]> = new Map();
  private anomalyThresholds = {
    priceJump: 0.15, // 15% jump is suspicious
    volumeSpike: 3.0, // 3x volume is suspicious
    timeGap: 60000, // 60 seconds gap is suspicious
  };

  /**
   * Generate cryptographic hash for data integrity
   */
  public generateDataHash(data: any): string {
    const jsonString = JSON.stringify(data);
    const hash = crypto.createHash('sha256').update(jsonString).digest('hex');
    return hash;
  }

  /**
   * Verify data integrity with hash
   */
  public verifyDataIntegrity(data: any, expectedHash: string): IntegrityCheckResult {
    const calculatedHash = this.generateDataHash(data);
    const isValid = calculatedHash === expectedHash;
    const timestamp = Date.now();
    const checksum = this.generateChecksum(data);
    const anomalies = this.detectAnomalies(data);

    return {
      isValid,
      hash: calculatedHash,
      timestamp,
      checksum,
      anomalies,
    };
  }

  /**
   * Generate checksum for quick validation
   */
  private generateChecksum(data: any): string {
    const jsonString = JSON.stringify(data);
    let checksum = 0;
    for (let i = 0; i < jsonString.length; i++) {
      checksum = ((checksum << 5) - checksum) + jsonString.charCodeAt(i);
      checksum = checksum & checksum; // Convert to 32-bit integer
    }
    return Math.abs(checksum).toString(16);
  }

  /**
   * Detect anomalies in market data
   */
  private detectAnomalies(data: any): string[] {
    const anomalies: string[] = [];

    // Check for extreme price movements
    if (data.close && data.open) {
      const priceChange = Math.abs((data.close - data.open) / data.open);
      if (priceChange > this.anomalyThresholds.priceJump) {
        anomalies.push(`Extreme price jump: ${(priceChange * 100).toFixed(2)}%`);
      }
    }

    // Check for volume spikes
    if (data.volume && data.avgVolume) {
      const volumeRatio = data.volume / data.avgVolume;
      if (volumeRatio > this.anomalyThresholds.volumeSpike) {
        anomalies.push(`Volume spike: ${volumeRatio.toFixed(2)}x normal`);
      }
    }

    // Check for suspicious timestamps
    if (data.timestamp) {
      const now = Date.now();
      const timeDiff = now - data.timestamp;
      if (timeDiff < 0) {
        anomalies.push('Future timestamp detected');
      }
      if (timeDiff > 86400000) {
        // 24 hours
        anomalies.push('Stale data detected');
      }
    }

    // Check for NaN or invalid values
    if (isNaN(data.open) || isNaN(data.high) || isNaN(data.low) || isNaN(data.close)) {
      anomalies.push('Invalid OHLC values detected');
    }

    // Check OHLC logic
    if (data.high < data.low || data.high < data.open || data.high < data.close) {
      anomalies.push('Invalid OHLC relationship');
    }

    return anomalies;
  }

  /**
   * Encrypt sensitive data (API keys, credentials)
   */
  public encryptData(data: string, encryptionKey: string): string {
    try {
      const iv = crypto.randomBytes(16);
      const key = crypto.scryptSync(encryptionKey, 'salt', 32);
      const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);

      let encrypted = cipher.update(data, 'utf8', 'hex');
      encrypted += cipher.final('hex');

      // Prepend IV to encrypted data
      return iv.toString('hex') + ':' + encrypted;
    } catch (error) {
      console.error('[Security] Encryption error:', error);
      throw error;
    }
  }

  /**
   * Decrypt sensitive data
   */
  public decryptData(encryptedData: string, encryptionKey: string): string {
    try {
      const parts = encryptedData.split(':');
      const iv = Buffer.from(parts[0], 'hex');
      const encrypted = parts[1];

      const key = crypto.scryptSync(encryptionKey, 'salt', 32);
      const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

      let decrypted = decipher.update(encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');

      return decrypted;
    } catch (error) {
      console.error('[Security] Decryption error:', error);
      throw error;
    }
  }

  /**
   * Generate anti-blocking request headers
   */
  public generateAntiBlockingHeaders(): Record<string, string> {
    const userAgents = [
      'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15',
      'Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36',
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
    ];

    const randomUserAgent = userAgents[Math.floor(Math.random() * userAgents.length)];

    return {
      'User-Agent': randomUserAgent,
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'cross-site',
      'X-Requested-With': 'XMLHttpRequest',
      'Referer': 'https://www.google.com/',
      'Origin': 'https://www.google.com',
      'DNT': '1',
    };
  }

  /**
   * Rate limiting: Check if request should be throttled
   */
  public checkRateLimit(key: string, maxRequests: number = 10, timeWindow: number = 60000): boolean {
    const now = Date.now();
    const timestamps = this.requestTimestamps.get(key) || [];

    // Remove old timestamps outside time window
    const validTimestamps = timestamps.filter(ts => now - ts < timeWindow);

    if (validTimestamps.length >= maxRequests) {
      return false; // Rate limit exceeded
    }

    validTimestamps.push(now);
    this.requestTimestamps.set(key, validTimestamps);
    return true; // Request allowed
  }

  /**
   * Add random delay to avoid detection
   */
  public async addRandomDelay(minMs: number = 100, maxMs: number = 1000): Promise<void> {
    const delay = Math.random() * (maxMs - minMs) + minMs;
    return new Promise(resolve => setTimeout(resolve, delay));
  }

  /**
   * Validate data against historical patterns
   */
  public validateAgainstHistorical(
    currentData: any,
    historicalData: any[],
    tolerancePercent: number = 10
  ): { isValid: boolean; deviations: string[] } {
    const deviations: string[] = [];

    if (historicalData.length === 0) {
      return { isValid: true, deviations: [] };
    }

    // Calculate average values from historical data
    const avgOpen = historicalData.reduce((sum, d) => sum + d.open, 0) / historicalData.length;
    const avgClose = historicalData.reduce((sum, d) => sum + d.close, 0) / historicalData.length;
    const avgVolume = historicalData.reduce((sum, d) => sum + d.volume, 0) / historicalData.length;

    // Check deviation tolerance
    const tolerance = tolerancePercent / 100;

    if (Math.abs((currentData.open - avgOpen) / avgOpen) > tolerance) {
      deviations.push(`Open price deviation: ${((currentData.open - avgOpen) / avgOpen * 100).toFixed(2)}%`);
    }

    if (Math.abs((currentData.close - avgClose) / avgClose) > tolerance) {
      deviations.push(`Close price deviation: ${((currentData.close - avgClose) / avgClose * 100).toFixed(2)}%`);
    }

    if (Math.abs((currentData.volume - avgVolume) / avgVolume) > tolerance * 2) {
      deviations.push(`Volume deviation: ${((currentData.volume - avgVolume) / avgVolume * 100).toFixed(2)}%`);
    }

    return {
      isValid: deviations.length === 0,
      deviations,
    };
  }

  /**
   * Generate request signature for API authentication
   */
  public generateRequestSignature(
    method: string,
    path: string,
    timestamp: number,
    secret: string,
    body?: any
  ): string {
    const message = `${method}${path}${timestamp}${body ? JSON.stringify(body) : ''}`;
    const signature = crypto.createHmac('sha256', secret).update(message).digest('hex');
    return signature;
  }

  /**
   * Detect man-in-the-middle (MITM) attacks
   */
  public detectMITM(
    originalData: any,
    receivedData: any,
    originalHash: string,
    receivedHash: string
  ): { isSuspicious: boolean; reason: string } {
    if (originalHash !== receivedHash) {
      return {
        isSuspicious: true,
        reason: 'Data hash mismatch - possible MITM attack',
      };
    }

    // Check if critical fields were modified
    const criticalFields = ['open', 'high', 'low', 'close', 'volume', 'timestamp'];
    for (const field of criticalFields) {
      if (originalData[field] !== receivedData[field]) {
        return {
          isSuspicious: true,
          reason: `Critical field modified: ${field}`,
        };
      }
    }

    return {
      isSuspicious: false,
      reason: 'Data integrity verified',
    };
  }

  /**
   * Implement circuit breaker pattern for network resilience
   */
  public shouldCircuitBreak(failureCount: number, successCount: number): boolean {
    const failureRate = failureCount / (failureCount + successCount);
    const threshold = 0.5; // 50% failure rate

    if (failureRate > threshold && failureCount > 5) {
      return true; // Circuit breaker activated
    }

    return false;
  }

  /**
   * Generate secure random token
   */
  public generateSecureToken(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * Validate certificate pinning for HTTPS
   */
  public validateCertificatePinning(certificateHash: string, expectedHash: string): boolean {
    return certificateHash === expectedHash;
  }
}

/**
 * Factory function to create security service
 */
export function createSecurityService(): SecurityService {
  return new SecurityService();
}
