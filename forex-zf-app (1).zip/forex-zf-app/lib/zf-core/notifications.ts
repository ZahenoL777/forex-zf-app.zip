/**
 * Push Notifications & Alerts Service
 *
 * Real-time alerts for:
 * - ZF-Score critical levels
 * - Inflection points detected
 * - Circuit breaker triggered
 * - Position updates
 * - Trade execution confirmations
 */

import * as Notifications from 'expo-notifications';

/**
 * Alert types and priorities
 */
export enum AlertType {
  CIRCUIT_BREAKER = 'CIRCUIT_BREAKER',
  ZF_SCORE_CRITICAL = 'ZF_SCORE_CRITICAL',
  INFLECTION_POINT = 'INFLECTION_POINT',
  LIQUIDITY_VOID = 'LIQUIDITY_VOID',
  STRUCTURAL_BREAK = 'STRUCTURAL_BREAK',
  TRADE_EXECUTED = 'TRADE_EXECUTED',
  POSITION_CLOSED = 'POSITION_CLOSED',
  PROFIT_TARGET_HIT = 'PROFIT_TARGET_HIT',
  STOP_LOSS_HIT = 'STOP_LOSS_HIT',
}

export enum AlertPriority {
  LOW = 1,
  MEDIUM = 2,
  HIGH = 3,
  CRITICAL = 4,
}

/**
 * Alert configuration
 */
export interface AlertConfig {
  type: AlertType;
  title: string;
  body: string;
  priority: AlertPriority;
  data?: Record<string, any>;
  sound?: boolean;
  vibration?: boolean;
}

/**
 * Notification Service
 */
export class NotificationService {
  private isInitialized: boolean = false;
  private alertHistory: AlertConfig[] = [];
  private maxHistorySize: number = 100;

  /**
   * Initialize notification service
   */
  public async initialize(): Promise<void> {
    try {
      // Request permissions
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') {
        console.warn('[Notifications] Permission not granted');
      }

      // Set notification handler
      Notifications.setNotificationHandler({
        handleNotification: async notification => {
          console.log('[Notifications] Received:', notification);
          return {
            shouldShowAlert: true,
            shouldPlaySound: true,
            shouldSetBadge: true,
            shouldShowBanner: true,
            shouldShowList: true,
          } as any;
        },
      });

      this.isInitialized = true;
      console.log('[Notifications] Service initialized');
    } catch (error) {
      console.error('[Notifications] Initialization error:', error);
    }
  }

  /**
   * Send local notification
   */
  public async sendNotification(config: AlertConfig): Promise<string | null> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    try {
      // Add to history
      this.alertHistory.push(config);
      if (this.alertHistory.length > this.maxHistorySize) {
        this.alertHistory.shift();
      }

      // Prepare notification
      const notificationContent: Notifications.NotificationContentInput = {
        title: config.title,
        body: config.body,
        data: config.data || {},
        sound: config.sound !== false ? 'default' : undefined,
        badge: this.getPriorityBadge(config.priority),
      };

      // Send notification
      const notificationId = await Notifications.scheduleNotificationAsync({
        content: notificationContent,
        trigger: null, // Send immediately
      });

      console.log(`[Notifications] Sent: ${config.type}`);
      return notificationId;
    } catch (error) {
      console.error('[Notifications] Send error:', error);
      return null;
    }
  }

  /**
   * Send ZF-Score critical alert
   */
  public async alertZFScoreCritical(symbol: string, zfScore: number): Promise<void> {
    await this.sendNotification({
      type: AlertType.ZF_SCORE_CRITICAL,
      title: 'ZF-Score Critical',
      body: `${symbol}: ZF-Score ${zfScore.toFixed(2)} - Critical level detected`,
      priority: AlertPriority.HIGH,
      data: { symbol, zfScore },
      sound: true,
      vibration: true,
    });
  }

  /**
   * Send circuit breaker alert
   */
  public async alertCircuitBreaker(symbol: string): Promise<void> {
    await this.sendNotification({
      type: AlertType.CIRCUIT_BREAKER,
      title: 'Circuit Breaker',
      body: `${symbol}: Circuit breaker activated - Trading halted for 30 minutes`,
      priority: AlertPriority.CRITICAL,
      data: { symbol },
      sound: true,
      vibration: true,
    });
  }

  /**
   * Send inflection point alert
   */
  public async alertInflectionPoint(symbol: string, timeframe: string): Promise<void> {
    await this.sendNotification({
      type: AlertType.INFLECTION_POINT,
      title: 'Inflection Point',
      body: `${symbol} ${timeframe}: Momentum exhaustion detected - Potential reversal`,
      priority: AlertPriority.MEDIUM,
      data: { symbol, timeframe },
      sound: true,
    });
  }

  /**
   * Send trade executed alert
   */
  public async alertTradeExecuted(symbol: string, side: string, quantity: number, price: number): Promise<void> {
    await this.sendNotification({
      type: AlertType.TRADE_EXECUTED,
      title: 'Trade Executed',
      body: `${side} ${quantity} ${symbol} @ ${price.toFixed(5)}`,
      priority: AlertPriority.HIGH,
      data: { symbol, side, quantity, price },
      sound: true,
    });
  }

  /**
   * Send profit target hit alert
   */
  public async alertProfitTargetHit(symbol: string, profit: number): Promise<void> {
    await this.sendNotification({
      type: AlertType.PROFIT_TARGET_HIT,
      title: 'Profit Target Hit',
      body: `${symbol}: Position closed with profit $${profit.toFixed(2)}`,
      priority: AlertPriority.HIGH,
      data: { symbol, profit },
      sound: true,
      vibration: true,
    });
  }

  /**
   * Send stop loss alert
   */
  public async alertStopLossHit(symbol: string, loss: number): Promise<void> {
    await this.sendNotification({
      type: AlertType.STOP_LOSS_HIT,
      title: 'Stop Loss Hit',
      body: `${symbol}: Position closed with loss $${loss.toFixed(2)}`,
      priority: AlertPriority.HIGH,
      data: { symbol, loss },
      sound: true,
      vibration: true,
    });
  }

  /**
   * Get priority badge
   */
  private getPriorityBadge(priority: AlertPriority): number {
    switch (priority) {
      case AlertPriority.CRITICAL:
        return 3;
      case AlertPriority.HIGH:
        return 2;
      case AlertPriority.MEDIUM:
        return 1;
      default:
        return 0;
    }
  }

  /**
   * Get alert history
   */
  public getAlertHistory(): AlertConfig[] {
    return [...this.alertHistory];
  }

  /**
   * Clear alert history
   */
  public clearAlertHistory(): void {
    this.alertHistory = [];
  }

  /**
   * Get recent alerts
   */
  public getRecentAlerts(count: number = 10): AlertConfig[] {
    return this.alertHistory.slice(-count);
  }

  /**
   * Schedule recurring notification
   */
  public async scheduleRecurringNotification(
    config: AlertConfig,
    intervalSeconds: number
  ): Promise<string | null> {
    try {
      const notificationId = await Notifications.scheduleNotificationAsync({
        content: {
          title: config.title,
          body: config.body,
          data: config.data || {},
        },
        trigger: {
          type: 'time' as any,
          seconds: intervalSeconds,
          repeats: true,
        } as any,
      })

      console.log(`[Notifications] Scheduled recurring: ${config.type}`);
      return notificationId;
    } catch (error) {
      console.error('[Notifications] Schedule error:', error);
      return null;
    }
  }

  /**
   * Cancel notification
   */
  public async cancelNotification(notificationId: string): Promise<void> {
    try {
      await Notifications.cancelScheduledNotificationAsync(notificationId);
      console.log('[Notifications] Cancelled:', notificationId);
    } catch (error) {
      console.error('[Notifications] Cancel error:', error);
    }
  }

  /**
   * Cancel all notifications
   */
  public async cancelAllNotifications(): Promise<void> {
    try {
      await Notifications.cancelAllScheduledNotificationsAsync();
      console.log('[Notifications] All cancelled');
    } catch (error) {
      console.error('[Notifications] Cancel all error:', error);
    }
  }
}

/**
 * Factory function
 */
export function createNotificationService(): NotificationService {
  return new NotificationService();
}
