/**
 * Real-Time Data Sync Service
 * Implements WebSocket connections for tick-by-tick data from multiple markets
 * 
 * Supports:
 * - Forex pairs (EUR/USD, GBP/USD, USD/JPY, etc.) via Binance or alternative
 * - BTC/USD via Binance, Kraken, or Coinbase
 * - Data normalization & integrity verification
 * - Session memory archival
 */

import { MarketData, ZFCoreResult } from './calculations';

/**
 * Tick data structure for real-time price updates
 */
export interface TickData {
  symbol: string; // e.g., "EURUSD", "BTCUSD"
  timestamp: number; // Microsecond precision
  price: number; // Last traded price
  bid: number; // Best bid price
  ask: number; // Best ask price
  volume: number; // Volume of this tick
  bidVolume: number; // Volume on bid side
  askVolume: number; // Volume on ask side
}

/**
 * Order book snapshot
 */
export interface OrderBookSnapshot {
  symbol: string;
  timestamp: number;
  bidLevels: Array<{ price: number; volume: number }>;
  askLevels: Array<{ price: number; volume: number }>;
}

/**
 * Session data for archival & cross-validation
 */
export interface SessionSnapshot {
  timestamp: number;
  symbol: string;
  dRes: number; // Topological Drift
  zfScore: number; // ZF-Score
  lambda: number; // Elasticity coefficient
  liquidityVoid: boolean; // Liquidity void status
  pPure: number; // Pure resonance price
  priceHistory: number[]; // Last 100 prices for inflection detection
}

/**
 * Data sync configuration
 */
export interface DataSyncConfig {
  symbols: string[]; // List of symbols to monitor (e.g., ["EURUSD", "GBPUSD", "BTCUSD"])
  tickBufferSize: number; // Number of ticks to keep in memory
  orderBookDepth: number; // Number of order book levels to track
  sessionArchiveInterval: number; // Milliseconds between session snapshots
  dataValidationTimeout: number; // Milliseconds to wait for data integrity check
}

/**
 * Real-time data sync manager
 */
export class DataSyncManager {
  private config: DataSyncConfig;
  private tickBuffer: Map<string, TickData[]> = new Map();
  private orderBookBuffer: Map<string, OrderBookSnapshot> = new Map();
  private sessionArchive: SessionSnapshot[] = [];
  private websockets: Map<string, WebSocket> = new Map();
  private volumeBaseline: Map<string, number> = new Map(); // 24h average volume
  private lastArchiveTime: number = 0;

  constructor(config: DataSyncConfig) {
    this.config = config;
    this.initializeBuffers();
  }

  /**
   * Initialize tick and order book buffers for all symbols
   */
  private initializeBuffers(): void {
    for (const symbol of this.config.symbols) {
      this.tickBuffer.set(symbol, []);
      this.orderBookBuffer.set(symbol, {
        symbol,
        timestamp: 0,
        bidLevels: [],
        askLevels: [],
      });
    }
  }

  /**
   * Connect to Binance WebSocket for real-time data
   * 
   * Binance provides:
   * - Forex pairs via spot trading (EURUSDT, GBPUSDT, etc.)
   * - BTC via spot trading (BTCUSDT)
   * - Order book depth stream
   * - Aggregate trade stream
   */
  public async connectToBinance(): Promise<void> {
    for (const symbol of this.config.symbols) {
      const wsUrl = this.getBinanceWebSocketUrl(symbol);
      
      try {
        const ws = new WebSocket(wsUrl);
        
        ws.onopen = () => {
          console.log(`[DataSync] Connected to Binance: ${symbol}`);
        };

        ws.onmessage = (event: MessageEvent) => {
          this.handleBinanceMessage(symbol, event.data);
        };

        ws.onerror = (error: Event) => {
          console.error(`[DataSync] WebSocket error for ${symbol}:`, error);
        };

        ws.onclose = () => {
          console.log(`[DataSync] Disconnected from Binance: ${symbol}`);
          // Attempt reconnection after 5 seconds
          setTimeout(() => this.connectToBinance(), 5000);
        };

        this.websockets.set(symbol, ws);
      } catch (error) {
        console.error(`[DataSync] Failed to connect to Binance for ${symbol}:`, error);
      }
    }
  }

  /**
   * Get Binance WebSocket URL for a symbol
   * 
   * Binance WebSocket streams:
   * - aggTrade: Aggregate trade stream (tick data)
   * - depth@100ms: Order book depth updates
   */
  private getBinanceWebSocketUrl(symbol: string): string {
    const binanceSymbol = symbol.replace('/', '').toLowerCase();
    // Subscribe to both aggregate trades and depth updates
    return `wss://stream.binance.com:9443/ws/${binanceSymbol}@aggTrade/${binanceSymbol}@depth@100ms`;
  }

  /**
   * Handle incoming Binance WebSocket message
   */
  private handleBinanceMessage(symbol: string, data: string): void {
    try {
      const message = JSON.parse(data);

      // Handle aggregate trade (tick data)
      if (message.e === 'aggTrade') {
        const tickData: TickData = {
          symbol,
          timestamp: message.T, // Trade time in milliseconds
          price: parseFloat(message.p), // Price
          bid: parseFloat(message.p) * 0.9999, // Approximate bid (Binance doesn't provide in aggTrade)
          ask: parseFloat(message.p) * 1.0001, // Approximate ask
          volume: parseFloat(message.q), // Quantity
          bidVolume: parseFloat(message.q) * 0.5, // Estimate
          askVolume: parseFloat(message.q) * 0.5, // Estimate
        };

        this.addTickData(symbol, tickData);
      }

      // Handle order book depth
      if (message.e === 'depthUpdate') {
        const snapshot: OrderBookSnapshot = {
          symbol,
          timestamp: message.E,
          bidLevels: (message.b || []).slice(0, this.config.orderBookDepth).map((level: any[]) => ({
            price: parseFloat(level[0]),
            volume: parseFloat(level[1]),
          })),
          askLevels: (message.a || []).slice(0, this.config.orderBookDepth).map((level: any[]) => ({
            price: parseFloat(level[0]),
            volume: parseFloat(level[1]),
          })),
        };

        this.orderBookBuffer.set(symbol, snapshot);
      }
    } catch (error) {
      console.error(`[DataSync] Error processing Binance message for ${symbol}:`, error);
    }
  }

  /**
   * Add tick data to buffer with FIFO rotation
   */
  private addTickData(symbol: string, tick: TickData): void {
    const buffer = this.tickBuffer.get(symbol) || [];
    buffer.push(tick);

    // Keep only the last N ticks
    if (buffer.length > this.config.tickBufferSize) {
      buffer.shift();
    }

    this.tickBuffer.set(symbol, buffer);
  }

  /**
   * Get current market data for ZF-Core calculation
   */
  public getMarketData(symbol: string): MarketData | null {
    const ticks = this.tickBuffer.get(symbol);
    const orderBook = this.orderBookBuffer.get(symbol);

    if (!ticks || ticks.length === 0 || !orderBook) {
      return null;
    }

    const lastTick = ticks[ticks.length - 1];
    const pMarket = lastTick.price;

    // Calculate pure resonance price from order book
    const pPure = this.calculatePureResonancePrice(orderBook);

    // Calculate abnormal volume
    const vAbs = this.calculateAbnormalVolume(symbol, ticks);
    const vTotal = this.calculateTotalVolume(orderBook);

    // Calculate elasticity coefficient from bid-ask spread
    const lambda = this.calculateLambda(lastTick.bid, lastTick.ask, pMarket);

    // Extract bid/ask depths and volumes
    const bidDepth = orderBook.bidLevels.map(level => level.volume);
    const askDepth = orderBook.askLevels.map(level => level.volume);
    const bidVolume = orderBook.bidLevels.map(level => level.volume);
    const askVolume = orderBook.askLevels.map(level => level.volume);

    return {
      pMarket,
      pPure,
      vAbs,
      vTotal,
      bidDepth,
      askDepth,
      bidVolume,
      askVolume,
      lambda,
      timestamp: lastTick.timestamp,
    };
  }

  /**
   * Calculate pure resonance price from order book
   */
  private calculatePureResonancePrice(orderBook: OrderBookSnapshot): number {
    const bidWeighted = orderBook.bidLevels.reduce(
      (sum, level) => sum + level.price * level.volume,
      0
    );
    const askWeighted = orderBook.askLevels.reduce(
      (sum, level) => sum + level.price * level.volume,
      0
    );

    const totalBidVolume = orderBook.bidLevels.reduce((sum, level) => sum + level.volume, 0);
    const totalAskVolume = orderBook.askLevels.reduce((sum, level) => sum + level.volume, 0);
    const totalVolume = totalBidVolume + totalAskVolume;

    if (totalVolume === 0) {
      return (orderBook.bidLevels[0]?.price + orderBook.askLevels[0]?.price) / 2 || 0;
    }

    return (bidWeighted + askWeighted) / totalVolume;
  }

  /**
   * Calculate abnormal volume (deviation from 24h average)
   */
  private calculateAbnormalVolume(symbol: string, ticks: TickData[]): number {
    if (ticks.length === 0) return 0;

    const recentVolume = ticks.slice(-100).reduce((sum, tick) => sum + tick.volume, 0);
    const avgVolume = this.volumeBaseline.get(symbol) || recentVolume;

    return Math.abs(recentVolume - avgVolume);
  }

  /**
   * Calculate total volume on order book
   */
  private calculateTotalVolume(orderBook: OrderBookSnapshot): number {
    const bidTotal = orderBook.bidLevels.reduce((sum, level) => sum + level.volume, 0);
    const askTotal = orderBook.askLevels.reduce((sum, level) => sum + level.volume, 0);
    return bidTotal + askTotal;
  }

  /**
   * Calculate elasticity coefficient from bid-ask spread
   */
  private calculateLambda(bid: number, ask: number, mid: number): number {
    const spread = ask - bid;
    const spreadPercent = (spread / mid) * 100;
    return Math.max(0, Math.min(1, 1 / (1 + spreadPercent)));
  }

  /**
   * Get price history for inflection point detection
   */
  public getPriceHistory(symbol: string, length: number = 100): number[] {
    const ticks = this.tickBuffer.get(symbol) || [];
    return ticks.slice(-length).map(tick => tick.price);
  }

  /**
   * Archive session data for cross-validation
   */
  public archiveSession(symbol: string, result: ZFCoreResult, pPure: number, lambda: number): void {
    const snapshot: SessionSnapshot = {
      timestamp: result.timestamp,
      symbol,
      dRes: result.dRes,
      zfScore: result.zfScore,
      lambda,
      liquidityVoid: result.liquidityStatus === 'void',
      pPure,
      priceHistory: this.getPriceHistory(symbol, 100),
    };

    this.sessionArchive.push(snapshot);

    // Keep only last 1000 snapshots per symbol
    if (this.sessionArchive.length > 1000) {
      this.sessionArchive.shift();
    }

    this.lastArchiveTime = Date.now();
  }

  /**
   * Get session history for cross-validation
   */
  public getSessionHistory(symbol: string, limit: number = 100): SessionSnapshot[] {
    return this.sessionArchive
      .filter(snap => snap.symbol === symbol)
      .slice(-limit);
  }

  /**
   * Validate data integrity (check for packet loss or corruption)
   */
  public validateDataIntegrity(symbol: string): { isValid: boolean; gaps: number } {
    const ticks = this.tickBuffer.get(symbol) || [];
    if (ticks.length < 2) return { isValid: true, gaps: 0 };

    let gaps = 0;
    const expectedInterval = 100; // Expected interval in milliseconds (rough estimate)

    for (let i = 1; i < ticks.length; i++) {
      const timeDiff = ticks[i].timestamp - ticks[i - 1].timestamp;
      if (timeDiff > expectedInterval * 2) {
        gaps++;
      }
    }

    const isValid = gaps < ticks.length * 0.05; // Allow < 5% gaps
    return { isValid, gaps };
  }

  /**
   * Detect anomalies in data stream
   */
  public detectAnomalies(symbol: string): { hasAnomaly: boolean; reason: string } {
    const ticks = this.tickBuffer.get(symbol) || [];
    if (ticks.length < 10) return { hasAnomaly: false, reason: 'Insufficient data' };

    // Check for extreme price movements
    const recentPrices = ticks.slice(-10).map(t => t.price);
    const minPrice = Math.min(...recentPrices);
    const maxPrice = Math.max(...recentPrices);
    const priceChange = ((maxPrice - minPrice) / minPrice) * 100;

    if (priceChange > 10) {
      return { hasAnomaly: true, reason: `Extreme price movement: ${priceChange.toFixed(2)}%` };
    }

    // Check for data gaps
    const { gaps } = this.validateDataIntegrity(symbol);
    if (gaps > 5) {
      return { hasAnomaly: true, reason: `Data gaps detected: ${gaps}` };
    }

    return { hasAnomaly: false, reason: 'Normal' };
  }

  /**
   * Disconnect all WebSocket connections
   */
  public disconnect(): void {
    for (const [symbol, ws] of this.websockets) {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    }
    this.websockets.clear();
  }

  /**
   * Get sync status for all symbols
   */
  public getSyncStatus(): Record<string, { connected: boolean; tickCount: number; lastUpdate: number }> {
    const status: Record<string, any> = {};

    for (const symbol of this.config.symbols) {
      const ticks = this.tickBuffer.get(symbol) || [];
      const lastTick = ticks[ticks.length - 1];
      const ws = this.websockets.get(symbol);

      status[symbol] = {
        connected: ws?.readyState === WebSocket.OPEN,
        tickCount: ticks.length,
        lastUpdate: lastTick?.timestamp || 0,
      };
    }

    return status;
  }
}

/**
 * Factory function to create and initialize data sync manager
 */
export function createDataSyncManager(symbols: string[]): DataSyncManager {
  const config: DataSyncConfig = {
    symbols,
    tickBufferSize: 10000, // Keep last 10k ticks
    orderBookDepth: 20, // Track top 20 bid/ask levels
    sessionArchiveInterval: 60000, // Archive every 60 seconds
    dataValidationTimeout: 5000, // 5 second timeout for validation
  };

  return new DataSyncManager(config);
}
