/**
 * Market Monitor Service
 * Combines real-time data sync with ZF-Core analysis
 * Monitors 200+ Forex pairs and BTC for anomalies and trading signals
 */

import { DataSyncManager, createDataSyncManager } from './data-sync';
import { analyzeWithZFCore, detectStructuralBreak, ZFCoreResult } from './calculations';

/**
 * Market alert types
 */
export enum AlertType {
  ZF_SCORE_CRITICAL = 'zf_score_critical', // ZF-Score > 0.8
  CIRCUIT_BREAKER = 'circuit_breaker', // ZF-Score > 0.99
  STRUCTURAL_BREAK = 'structural_break', // Divergence from historical data
  LIQUIDITY_VOID = 'liquidity_void', // Order book thinning
  RESONANCE_MISMATCH = 'resonance_mismatch', // Historical divergence
  INFLECTION_POINT = 'inflection_point', // Momentum exhaustion detected
  DATA_ANOMALY = 'data_anomaly', // Unusual data pattern
}

/**
 * Market alert
 */
export interface MarketAlert {
  type: AlertType;
  symbol: string;
  timestamp: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  data: any; // Alert-specific data
}

/**
 * Market analysis result
 */
export interface MarketAnalysis {
  symbol: string;
  timestamp: number;
  zfCoreResult: ZFCoreResult;
  alerts: MarketAlert[];
  recommendation: string;
  confidence: number;
}

/**
 * Market monitor configuration
 */
export interface MarketMonitorConfig {
  symbols: string[];
  analysisInterval: number; // Milliseconds between analyses
  alertThresholds: {
    zfScoreCritical: number; // Default: 0.8
    circuitBreaker: number; // Default: 0.99
    structuralBreakSigma: number; // Default: 3
  };
  enableAutoArchive: boolean;
}

/**
 * Market Monitor Service
 */
export class MarketMonitor {
  private dataSyncManager: DataSyncManager;
  private config: MarketMonitorConfig;
  private analysisInterval: ReturnType<typeof setInterval> | null = null;
  private alerts: MarketAlert[] = [];
  private analysisHistory: Map<string, MarketAnalysis[]> = new Map();
  private listeners: ((alert: MarketAlert) => void)[] = [];

  constructor(config: MarketMonitorConfig) {
    this.config = config;
    this.dataSyncManager = createDataSyncManager(config.symbols);
    this.initializeAnalysisHistory();
  }

  /**
   * Initialize analysis history for all symbols
   */
  private initializeAnalysisHistory(): void {
    for (const symbol of this.config.symbols) {
      this.analysisHistory.set(symbol, []);
    }
  }

  /**
   * Start monitoring
   */
  public async start(): Promise<void> {
    console.log('[MarketMonitor] Starting market monitoring...');

    // Connect to data sources
    await this.dataSyncManager.connectToBinance();

    // Start periodic analysis
    this.analysisInterval = setInterval(() => {
      this.runAnalysis();
    }, this.config.analysisInterval) as ReturnType<typeof setInterval>;

    console.log('[MarketMonitor] Market monitoring started');
  }

  /**
   * Stop monitoring
   */
  public stop(): void {
    if (this.analysisInterval !== null) {
      clearInterval(this.analysisInterval as any);
      this.analysisInterval = null;
    }
    this.dataSyncManager.disconnect();
    console.log('[MarketMonitor] Market monitoring stopped');
  }

  /**
   * Run analysis for all monitored symbols
   */
  private runAnalysis(): void {
    for (const symbol of this.config.symbols) {
      try {
        const analysis = this.analyzeSymbol(symbol);
        if (analysis) {
          this.processAnalysis(analysis);
        }
      } catch (error) {
        console.error(`[MarketMonitor] Error analyzing ${symbol}:`, error);
      }
    }
  }

  /**
   * Analyze a single symbol
   */
  private analyzeSymbol(symbol: string): MarketAnalysis | null {
    const marketData = this.dataSyncManager.getMarketData(symbol);
    if (!marketData) {
      return null;
    }

    const priceHistory = this.dataSyncManager.getPriceHistory(symbol);
    if (priceHistory.length < 3) {
      return null;
    }

    // Run ZF-Core analysis
    const zfCoreResult = analyzeWithZFCore(marketData, priceHistory);

    // Generate alerts
    const alerts = this.generateAlerts(symbol, zfCoreResult, marketData);

    // Archive session data
    if (this.config.enableAutoArchive) {
      this.dataSyncManager.archiveSession(symbol, zfCoreResult, marketData.pPure, marketData.lambda);
    }

    // Build analysis result
    const analysis: MarketAnalysis = {
      symbol,
      timestamp: zfCoreResult.timestamp,
      zfCoreResult,
      alerts,
      recommendation: this.generateRecommendation(zfCoreResult, alerts),
      confidence: zfCoreResult.confidence,
    };

    // Store in history
    const history = this.analysisHistory.get(symbol) || [];
    history.push(analysis);
    if (history.length > 1000) {
      history.shift();
    }
    this.analysisHistory.set(symbol, history);

    return analysis;
  }

  /**
   * Generate alerts based on analysis
   */
  private generateAlerts(symbol: string, result: ZFCoreResult, marketData: any): MarketAlert[] {
    const alerts: MarketAlert[] = [];

    // Circuit breaker alert
    if (result.zfScore > this.config.alertThresholds.circuitBreaker) {
      alerts.push({
        type: AlertType.CIRCUIT_BREAKER,
        symbol,
        timestamp: result.timestamp,
        severity: 'critical',
        message: `Circuit breaker triggered for ${symbol}: ZF-Score ${result.zfScore.toFixed(3)}`,
        data: { zfScore: result.zfScore },
      });
    }

    // Critical ZF-Score alert
    if (result.zfScore > this.config.alertThresholds.zfScoreCritical) {
      alerts.push({
        type: AlertType.ZF_SCORE_CRITICAL,
        symbol,
        timestamp: result.timestamp,
        severity: 'high',
        message: `Critical ZF-Score for ${symbol}: ${result.zfScore.toFixed(3)}`,
        data: { zfScore: result.zfScore, dRes: result.dRes },
      });
    }

    // Liquidity void alert
    if (result.liquidityStatus === 'void') {
      alerts.push({
        type: AlertType.LIQUIDITY_VOID,
        symbol,
        timestamp: result.timestamp,
        severity: 'high',
        message: `Liquidity void detected for ${symbol}`,
        data: { bidAskRatio: marketData.bidVolume.reduce((a: number, b: number) => a + b, 0) / marketData.askVolume.reduce((a: number, b: number) => a + b, 0) },
      });
    }

    // Inflection point alert
    if (Math.abs(result.inflectionPoint) < 0.01) {
      alerts.push({
        type: AlertType.INFLECTION_POINT,
        symbol,
        timestamp: result.timestamp,
        severity: 'medium',
        message: `Inflection point detected for ${symbol}: momentum exhaustion`,
        data: { inflectionPoint: result.inflectionPoint },
      });
    }

    // Data anomaly alert
    const anomaly = this.dataSyncManager.detectAnomalies(symbol);
    if (anomaly.hasAnomaly) {
      alerts.push({
        type: AlertType.DATA_ANOMALY,
        symbol,
        timestamp: result.timestamp,
        severity: 'medium',
        message: `Data anomaly for ${symbol}: ${anomaly.reason}`,
        data: { reason: anomaly.reason },
      });
    }

    // Structural break detection
    const history = this.analysisHistory.get(symbol) || [];
    if (history.length > 20) {
      const historicalScores = history.slice(-20).map(a => a.zfCoreResult.zfScore);
      const isBreak = detectStructuralBreak(result.zfScore, historicalScores);
      if (isBreak) {
        alerts.push({
          type: AlertType.STRUCTURAL_BREAK,
          symbol,
          timestamp: result.timestamp,
          severity: 'high',
          message: `Structural break detected for ${symbol}`,
          data: { currentScore: result.zfScore, historicalMean: historicalScores.reduce((a, b) => a + b, 0) / historicalScores.length },
        });
      }
    }

    return alerts;
  }

  /**
   * Generate trading recommendation based on analysis
   */
  private generateRecommendation(result: ZFCoreResult, alerts: MarketAlert[]): string {
    // Circuit breaker: liquidate all positions
    if (alerts.some(a => a.type === AlertType.CIRCUIT_BREAKER)) {
      return 'LIQUIDATE_ALL - Circuit breaker activated';
    }

    // Structural break: defensive mode
    if (alerts.some(a => a.type === AlertType.STRUCTURAL_BREAK)) {
      return 'DEFEND - Structural break detected, reduce exposure';
    }

    // Use ZF-Core recommendation
    switch (result.recommendation) {
      case 'execute':
        return 'EXECUTE - Resonance re-entry signal, favorable entry point';
      case 'defend':
        return 'DEFEND - Systematic defense required';
      case 'caution':
        return 'CAUTION - Elevated tension, monitor closely';
      case 'hold':
        return 'HOLD - Wait for clearer signal';
      default:
        return 'UNKNOWN';
    }
  }

  /**
   * Process analysis and emit alerts
   */
  private processAnalysis(analysis: MarketAnalysis): void {
    // Emit critical alerts
    for (const alert of analysis.alerts) {
      if (alert.severity === 'critical' || alert.severity === 'high') {
        this.alerts.push(alert);
        this.notifyListeners(alert);
      }
    }
  }

  /**
   * Subscribe to alerts
   */
  public onAlert(listener: (alert: MarketAlert) => void): void {
    this.listeners.push(listener);
  }

  /**
   * Notify all listeners of a new alert
   */
  private notifyListeners(alert: MarketAlert): void {
    for (const listener of this.listeners) {
      try {
        listener(alert);
      } catch (error) {
        console.error('[MarketMonitor] Error in alert listener:', error);
      }
    }
  }

  /**
   * Get recent alerts
   */
  public getRecentAlerts(limit: number = 100): MarketAlert[] {
    return this.alerts.slice(-limit);
  }

  /**
   * Get analysis history for a symbol
   */
  public getAnalysisHistory(symbol: string, limit: number = 100): MarketAnalysis[] {
    const history = this.analysisHistory.get(symbol) || [];
    return history.slice(-limit);
  }

  /**
   * Get current sync status
   */
  public getSyncStatus(): Record<string, any> {
    return this.dataSyncManager.getSyncStatus();
  }

  /**
   * Get market overview
   */
  public getMarketOverview(): {
    totalSymbols: number;
    criticalSymbols: number;
    recentAlerts: number;
    syncStatus: Record<string, any>;
  } {
    const syncStatus = this.getSyncStatus();
    const connectedSymbols = Object.values(syncStatus).filter((s: any) => s.connected).length;
    const criticalAlerts = this.alerts.filter(a => a.severity === 'critical').length;

    return {
      totalSymbols: this.config.symbols.length,
      criticalSymbols: criticalAlerts,
      recentAlerts: this.alerts.length,
      syncStatus,
    };
  }
}

/**
 * Factory function to create market monitor
 */
export function createMarketMonitor(symbols: string[]): MarketMonitor {
  const config: MarketMonitorConfig = {
    symbols,
    analysisInterval: 1000, // Analyze every 1 second
    alertThresholds: {
      zfScoreCritical: 0.8,
      circuitBreaker: 0.99,
      structuralBreakSigma: 3,
    },
    enableAutoArchive: true,
  };

  return new MarketMonitor(config);
}
