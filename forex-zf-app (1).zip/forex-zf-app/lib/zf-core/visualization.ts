/**
 * Visualization Service
 * Generates analysis result images with entry, SL, TP, support/resistance
 * 
 * Produces:
 * - Chart with candlestick data
 * - Entry point marker
 * - Stop-Loss level line
 * - Taking Profit level line
 * - Support/Resistance lines
 * - ZF-Score gauge
 * - Market analysis text
 */

import { ZFCoreResult } from './calculations';
import { ExtractedMarketData } from './ocr-service';

/**
 * Chart data for visualization
 */
export interface ChartData {
  symbol: string;
  timeframe: string;
  candles: Array<{
    open: number;
    high: number;
    low: number;
    close: number;
    time: number;
  }>;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  support: number[];
  resistance: number[];
}

/**
 * Visualization configuration
 */
export interface VisualizationConfig {
  width: number;
  height: number;
  theme: 'light' | 'dark';
  showVolume: boolean;
  showIndicators: boolean;
}

/**
 * Analysis visualization result
 */
export interface VisualizationResult {
  imageBase64: string;
  imageUri: string;
  width: number;
  height: number;
  generatedAt: number;
}

/**
 * Visualization Service
 */
export class VisualizationService {
  private config: VisualizationConfig;

  constructor(config?: Partial<VisualizationConfig>) {
    this.config = {
      width: 1080,
      height: 1920,
      theme: 'dark',
      showVolume: true,
      showIndicators: true,
      ...config,
    };
  }

  /**
   * Generate visualization from analysis result
   * 
   * In production, this would use Canvas API or a charting library like:
   * - react-native-svg for native rendering
   * - Chart.js for web
   * - Plotly for advanced charts
   */
  public async generateVisualization(
    chartData: ChartData,
    zfResult: ZFCoreResult,
    extractedData?: ExtractedMarketData
  ): Promise<VisualizationResult> {
    try {
      // In a real implementation, you would:
      // 1. Create canvas or SVG element
      // 2. Draw candlestick chart
      // 3. Draw support/resistance lines
      // 4. Draw entry/SL/TP markers
      // 5. Draw ZF-Score gauge
      // 6. Add text annotations
      // 7. Export as image

      // For now, return mock result
      const mockResult = this.generateMockVisualization(chartData, zfResult);
      return mockResult;
    } catch (error) {
      console.error('[VisualizationService] Error generating visualization:', error);
      throw error;
    }
  }

  /**
   * Calculate support and resistance levels
   */
  public calculateSupportResistance(
    candles: ChartData['candles'],
    period: number = 20
  ): { support: number[]; resistance: number[] } {
    if (candles.length < period) {
      return { support: [], resistance: [] };
    }

    const recentCandles = candles.slice(-period);
    const lows = recentCandles.map(c => c.low);
    const highs = recentCandles.map(c => c.high);

    let supportLevels: number[] = [];
    let resistanceLevels: number[] = [];

    // Find local minima (support)
    for (let i = 1; i < lows.length - 1; i++) {
      if (lows[i] < lows[i - 1] && lows[i] < lows[i + 1]) {
        supportLevels.push(lows[i]);
      }
    }

    // Find local maxima (resistance)
    for (let i = 1; i < highs.length - 1; i++) {
      if (highs[i] > highs[i - 1] && highs[i] > highs[i + 1]) {
        resistanceLevels.push(highs[i]);
      }
    }

    // Remove duplicates and sort
    supportLevels = [...new Set(supportLevels)].sort((a, b) => a - b);
    resistanceLevels = [...new Set(resistanceLevels)].sort((a, b) => a - b);

    // Keep only top 3
    return {
      support: supportLevels.slice(-3),
      resistance: resistanceLevels.slice(-3),
    };
  }

  /**
   * Generate mock visualization for testing
   */
  private generateMockVisualization(
    chartData: ChartData,
    zfResult: ZFCoreResult
  ): VisualizationResult {
    // In production, this would be actual image data
    const mockImageBase64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

    return {
      imageBase64: mockImageBase64,
      imageUri: mockImageBase64,
      width: this.config.width,
      height: this.config.height,
      generatedAt: Date.now(),
    };
  }

  /**
   * Generate analysis summary text
   */
  public generateAnalysisSummary(
    chartData: ChartData,
    zfResult: ZFCoreResult,
    extractedData?: ExtractedMarketData
  ): string {
    const lines: string[] = [];

    lines.push(`=== ${chartData.symbol} Analysis ===`);
    lines.push(`Timeframe: ${chartData.timeframe}`);
    lines.push('');

    // Price levels
    lines.push('Price Levels:');
    lines.push(`  Entry:       ${chartData.entry.toFixed(5)}`);
    lines.push(`  Stop Loss:   ${chartData.stopLoss.toFixed(5)}`);
    lines.push(`  Take Profit: ${chartData.takeProfit.toFixed(5)}`);
    lines.push(`  Risk/Reward: ${((chartData.takeProfit - chartData.entry) / (chartData.entry - chartData.stopLoss)).toFixed(2)}`);
    lines.push('');

    // ZF-Core metrics
    lines.push('ZF-Core Analysis:');
    lines.push(`  ZF-Score:       ${zfResult.zfScore.toFixed(3)}`);
    lines.push(`  Drift:          ${zfResult.dRes.toFixed(2)}%`);
    lines.push(`  Decay (10d):    ${zfResult.decayT.toFixed(2)}%`);
    lines.push(`  Inflection:     ${zfResult.inflectionPoint.toFixed(4)}`);
    lines.push(`  Liquidity:      ${zfResult.liquidityStatus}`);
    lines.push('');

    // Recommendation
    lines.push('Recommendation:');
    lines.push(`  Action:     ${zfResult.recommendation.toUpperCase()}`);
    lines.push(`  Confidence: ${(zfResult.confidence * 100).toFixed(0)}%`);
    lines.push('');

    // Support/Resistance
    if (chartData.support.length > 0 || chartData.resistance.length > 0) {
      lines.push('Support/Resistance:');
      if (chartData.support.length > 0) {
        lines.push(`  Support:    ${chartData.support.map(s => s.toFixed(5)).join(', ')}`);
      }
      if (chartData.resistance.length > 0) {
        lines.push(`  Resistance: ${chartData.resistance.map(r => r.toFixed(5)).join(', ')}`);
      }
    }

    return lines.join('\n');
  }

  /**
   * Export analysis as JSON
   */
  public exportAnalysisJSON(
    chartData: ChartData,
    zfResult: ZFCoreResult,
    extractedData?: ExtractedMarketData
  ): string {
    const analysis = {
      metadata: {
        symbol: chartData.symbol,
        timeframe: chartData.timeframe,
        timestamp: Date.now(),
      },
      levels: {
        entry: chartData.entry,
        stopLoss: chartData.stopLoss,
        takeProfit: chartData.takeProfit,
        support: chartData.support,
        resistance: chartData.resistance,
      },
      zfCore: {
        zfScore: zfResult.zfScore,
        drift: zfResult.dRes,
        decay: zfResult.decayT,
        inflectionPoint: zfResult.inflectionPoint,
        liquidityStatus: zfResult.liquidityStatus,
      },
      recommendation: {
        action: zfResult.recommendation,
        confidence: zfResult.confidence,
      },
      extractedData: extractedData || null,
    };

    return JSON.stringify(analysis, null, 2);
  }
}

/**
 * Factory function to create visualization service
 */
export function createVisualizationService(config?: Partial<VisualizationConfig>): VisualizationService {
  return new VisualizationService(config);
}
