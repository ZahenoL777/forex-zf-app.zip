/**
 * ZF-Core Calculation Engine
 * Implements all mathematical formulas from Zuhri Formalism V16.3
 * 
 * Core Concepts:
 * - Topological Drift (D_res): Deviation from pure resonance price
 * - ZF-Score: Stability index (0-1 scale)
 * - Resonance Decay: Energy release prediction over time
 * - Inflection Point: Momentum exhaustion detection
 * - Liquidity Clustering: Order book density analysis
 */

/**
 * Market data structure for calculations
 */
export interface MarketData {
  pMarket: number; // Last traded price
  pPure: number; // Pure resonance price (weighted liquidity average)
  vAbs: number; // Abnormal volume (deviation from 24h average)
  vTotal: number; // Total transaction volume on order book
  bidDepth: number[]; // Bid side order book depths at each level
  askDepth: number[]; // Ask side order book depths at each level
  bidVolume: number[]; // Bid side volumes at each level
  askVolume: number[]; // Ask side volumes at each level
  lambda: number; // Elasticity coefficient (from bid-ask spread)
  timestamp: number; // Microsecond precision timestamp
}

/**
 * ZF-Core calculation results
 */
export interface ZFCoreResult {
  dRes: number; // Topological Drift percentage
  zfScore: number; // Stability index (0-1)
  decayT: number; // Resonance decay prediction
  inflectionPoint: number; // d²P/dt² value (0 = inflection)
  liquidityStatus: 'normal' | 'clustering' | 'void'; // Liquidity condition
  recommendation: 'execute' | 'defend' | 'caution' | 'hold';
  confidence: number; // Confidence level (0-1)
  timestamp: number;
}

/**
 * 4.1. Topological Drift (D_res)
 * 
 * Formula: D_res = (|P_market - P_pure| / P_pure) * 100
 * 
 * Measures the degree of deviation from pure resonance price.
 * Large deviations indicate structural tension that precedes sharp corrections.
 * 
 * @param pMarket - Last traded price
 * @param pPure - Pure resonance price (equilibrium)
 * @returns Drift percentage (0-100+)
 */
export function calculateTopologicalDrift(pMarket: number, pPure: number): number {
  if (pPure === 0) return 0;
  return (Math.abs(pMarket - pPure) / pPure) * 100;
}

/**
 * 4.2. Resonance Decay (Decay_t)
 * 
 * Formula: Decay_t = ∫(0 to t) [lambda * D_res] dt
 * 
 * Predicts total energy release (price decline percentage) during time window t (days).
 * This integral accumulates tension deviation over time, yielding certain energy decay.
 * 
 * @param lambda - Elasticity coefficient (from bid-ask spread ratio)
 * @param dRes - Topological drift percentage
 * @param tDays - Time window in days
 * @returns Predicted decay percentage
 */
export function calculateResonanceDecay(lambda: number, dRes: number, tDays: number): number {
  // Simplified integral: assumes constant lambda and D_res over time window
  // In production, this would integrate actual price history
  const decayRate = lambda * (dRes / 100); // Convert drift percentage to decimal
  return decayRate * tDays * 100; // Return as percentage
}

/**
 * 4.3. ZF-Score (Fragility Index)
 * 
 * Formula: ZF_score = (V_abs / V_total) * tanh(D_res)
 * 
 * Classifies asset stability on 0-1 scale:
 * - < 0.5: Stable, resonating near pure price
 * - 0.5-0.8: Elevated tension, increased volatility
 * - > 0.8: Critical condition, structural disintegration likely
 * - > 0.99: Topological fracture imminent, circuit breaker triggers
 * 
 * @param vAbs - Abnormal volume (deviation from 24h average)
 * @param vTotal - Total volume on order book
 * @param dRes - Topological drift percentage
 * @returns ZF-Score (0-1 scale, may exceed 1 in extreme cases)
 */
export function calculateZFScore(vAbs: number, vTotal: number, dRes: number): number {
  if (vTotal === 0) return 0;
  
  const volumeRatio = vAbs / vTotal;
  const driftNormalized = Math.tanh(dRes / 100); // Normalize drift to 0-1 via tanh
  
  return volumeRatio * driftNormalized;
}

/**
 * 4.4. Inflection Point Detection
 * 
 * Formula: d²P / dt² = 0
 * 
 * Detects momentum exhaustion by checking second derivative.
 * When acceleration becomes zero, energy has reached saturation point.
 * This signals either stabilization or reversal.
 * 
 * Implementation: Uses price history to calculate second derivative
 * 
 * @param priceHistory - Array of prices [oldest ... newest] (minimum 3 points)
 * @returns Second derivative value (0 = inflection point)
 */
export function calculateInflectionPoint(priceHistory: number[]): number {
  if (priceHistory.length < 3) return 0;
  
  const n = priceHistory.length;
  const p0 = priceHistory[n - 3];
  const p1 = priceHistory[n - 2];
  const p2 = priceHistory[n - 1];
  
  // Discrete second derivative: d²P/dt² ≈ (p2 - 2*p1 + p0) / dt²
  // Assuming dt = 1 (normalized time steps)
  const secondDerivative = p2 - 2 * p1 + p0;
  
  return secondDerivative;
}

/**
 * 3.1. Depth Mapping & Liquidity Analysis
 * 
 * Analyzes order book structure to identify:
 * - Liquidity clustering (thick order accumulation)
 * - Liquidity void (thin order book)
 * - Bid-Ask imbalance (weakness/strength indicator)
 * 
 * @param bidDepth - Bid side depths
 * @param askDepth - Ask side depths
 * @param bidVolume - Bid side volumes
 * @param askVolume - Ask side volumes
 * @returns Liquidity status and metrics
 */
export function analyzeLiquidityStructure(
  bidDepth: number[],
  askDepth: number[],
  bidVolume: number[],
  askVolume: number[]
): { status: 'normal' | 'clustering' | 'void'; bidAskRatio: number; clusteringScore: number } {
  // Calculate bid-ask volume ratio
  const totalBidVolume = bidVolume.reduce((a, b) => a + b, 0);
  const totalAskVolume = askVolume.reduce((a, b) => a + b, 0);
  
  if (totalAskVolume === 0) {
    return { status: 'void', bidAskRatio: Infinity, clusteringScore: 0 };
  }
  
  const bidAskRatio = totalBidVolume / totalAskVolume;
  
  // Detect clustering: high concentration in top levels
  const topLevelBidVolume = bidVolume.slice(0, 3).reduce((a, b) => a + b, 0);
  const topLevelAskVolume = askVolume.slice(0, 3).reduce((a, b) => a + b, 0);
  const clusteringScore = (topLevelBidVolume + topLevelAskVolume) / (totalBidVolume + totalAskVolume);
  
  // Determine status
  let status: 'normal' | 'clustering' | 'void';
  if (totalBidVolume < 100 || totalAskVolume < 100) {
    status = 'void'; // Thin order book
  } else if (clusteringScore > 0.7) {
    status = 'clustering'; // Heavy concentration in top levels
  } else {
    status = 'normal'; // Healthy distribution
  }
  
  return { status, bidAskRatio, clusteringScore };
}

/**
 * Calculate pure resonance price (P_pure)
 * 
 * P_pure is the equilibrium price based on weighted liquidity integration.
 * It represents the "fair value" if market were free from speculation.
 * 
 * @param bidDepth - Bid side depths at each level
 * @param askDepth - Ask side depths at each level
 * @param bidPrices - Bid side prices at each level
 * @param askPrices - Ask side prices at each level
 * @returns Pure resonance price
 */
export function calculatePureResonancePrice(
  bidDepth: number[],
  askDepth: number[],
  bidPrices: number[],
  askPrices: number[]
): number {
  // Weighted average of bid and ask prices by volume
  const bidWeighted = bidPrices.reduce((sum, price, i) => sum + price * bidDepth[i], 0);
  const askWeighted = askPrices.reduce((sum, price, i) => sum + price * askDepth[i], 0);
  
  const totalBidVolume = bidDepth.reduce((a, b) => a + b, 0);
  const totalAskVolume = askDepth.reduce((a, b) => a + b, 0);
  const totalVolume = totalBidVolume + totalAskVolume;
  
  if (totalVolume === 0) return (bidPrices[0] + askPrices[0]) / 2;
  
  return (bidWeighted + askWeighted) / totalVolume;
}

/**
 * Calculate elasticity coefficient (lambda)
 * 
 * Lambda measures market resilience based on bid-ask spread.
 * Wider spreads = lower elasticity = market under stress.
 * 
 * @param bestBid - Best bid price
 * @param bestAsk - Best ask price
 * @param midPrice - Mid price (reference)
 * @returns Elasticity coefficient (0-1)
 */
export function calculateElasticityCoefficient(bestBid: number, bestAsk: number, midPrice: number): number {
  const spread = bestAsk - bestBid;
  const spreadPercent = (spread / midPrice) * 100;
  
  // Elasticity decreases as spread widens
  // lambda = 1 / (1 + spread%)
  const lambda = 1 / (1 + spreadPercent);
  
  return Math.max(0, Math.min(1, lambda)); // Clamp to 0-1
}

/**
 * Comprehensive ZF-Core analysis
 * 
 * Runs all calculations and returns complete analysis result
 * 
 * @param data - Market data structure
 * @param priceHistory - Recent price history for inflection detection
 * @returns Complete ZF-Core analysis result
 */
export function analyzeWithZFCore(data: MarketData, priceHistory: number[]): ZFCoreResult {
  // Calculate core metrics
  const dRes = calculateTopologicalDrift(data.pMarket, data.pPure);
  const zfScore = calculateZFScore(data.vAbs, data.vTotal, dRes);
  const decayT = calculateResonanceDecay(data.lambda, dRes, 10); // 10-day prediction
  const inflectionPoint = calculateInflectionPoint(priceHistory);
  
  // Analyze liquidity
  const liquidity = analyzeLiquidityStructure(
    data.bidDepth,
    data.askDepth,
    data.bidVolume,
    data.askVolume
  );
  
  // Determine recommendation based on ZF-Score and metrics
  let recommendation: 'execute' | 'defend' | 'caution' | 'hold';
  let confidence = 0.5;
  
  if (zfScore > 0.99) {
    recommendation = 'defend'; // Circuit breaker condition
    confidence = 0.95;
  } else if (zfScore > 0.8) {
    recommendation = 'caution'; // Critical condition
    confidence = 0.85;
  } else if (zfScore < 0.5 && inflectionPoint < 0.01 && liquidity.status === 'normal') {
    recommendation = 'execute'; // Resonance re-entry signal
    confidence = 0.8;
  } else {
    recommendation = 'hold'; // Wait for clearer signal
    confidence = 0.6;
  }
  
  return {
    dRes,
    zfScore,
    decayT,
    inflectionPoint,
    liquidityStatus: liquidity.status,
    recommendation,
    confidence,
    timestamp: data.timestamp,
  };
}

/**
 * Detect structural break (Topological Fracture)
 * 
 * Compares current ZF-Score with historical baseline to detect anomalies
 * 
 * @param currentZFScore - Current ZF-Score
 * @param historicalZFScores - Previous ZF-Scores (last 100 readings)
 * @returns True if structural break detected
 */
export function detectStructuralBreak(currentZFScore: number, historicalZFScores: number[]): boolean {
  if (historicalZFScores.length < 10) return false;
  
  const mean = historicalZFScores.reduce((a, b) => a + b, 0) / historicalZFScores.length;
  const variance = historicalZFScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) / historicalZFScores.length;
  const stdDev = Math.sqrt(variance);
  
  // Structural break if current score deviates > 3 sigma from mean
  const zScore = Math.abs((currentZFScore - mean) / stdDev);
  
  return zScore > 3;
}

/**
 * Calculate dynamic stop-loss based on 3-sigma threshold
 * 
 * @param entryPrice - Entry price
 * @param volatility - Current volatility (standard deviation of returns)
 * @returns Stop-loss price
 */
export function calculateDynamicStopLoss(entryPrice: number, volatility: number): number {
  const thresholdPercent = volatility * 3 * 100; // 3-sigma in percentage
  return entryPrice * (1 - thresholdPercent / 100);
}

/**
 * Calculate taking profit based on decay inflection point
 * 
 * @param entryPrice - Entry price
 * @param decayT - Resonance decay prediction
 * @returns Taking profit price
 */
export function calculateTakingProfit(entryPrice: number, decayT: number): number {
  const tpPercent = Math.min(decayT, 5); // Cap at 5% to avoid unrealistic targets
  return entryPrice * (1 + tpPercent / 100);
}
