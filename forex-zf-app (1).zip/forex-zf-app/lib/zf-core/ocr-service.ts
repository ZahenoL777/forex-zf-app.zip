/**
 * OCR Service for Market Data Extraction
 * Extracts OHLC data, timeframes, and market information from screenshots
 * 
 * Supports:
 * - Multi-timeframe detection (1m, 5m, 15m, 1h, 4h, 1d, 1w, 1M)
 * - OHLC (Open, High, Low, Close) value extraction
 * - Volume data extraction
 * - Pair/symbol identification
 * - Data validation & correction
 */

/**
 * Extracted market data from screenshot
 */
export interface ExtractedMarketData {
  symbol: string; // e.g., "EURUSD", "BTCUSD"
  timeframe: string; // e.g., "1h", "4h", "1d"
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp: number; // Candle close time
  confidence: number; // 0-1 confidence score
  rawText: string; // Raw OCR text for debugging
}

/**
 * Multi-timeframe extraction result
 */
export interface MultiTimeframeExtraction {
  symbol: string;
  extractedAt: number;
  timeframes: ExtractedMarketData[];
  overallConfidence: number;
  warnings: string[];
}

/**
 * OCR Service
 */
export class OCRService {
  private readonly SUPPORTED_TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w', '1M'];
  private readonly FOREX_PAIRS = [
    'EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'AUDUSD', 'USDCAD',
    'NZDUSD', 'EURJPY', 'GBPJPY', 'EURGBP', 'EURCAD', 'EURCHF',
    'AUDNZD', 'AUDJPY', 'GBPCHF', 'CHFJPY', 'CADCHF', 'NZDJPY',
  ];
  private readonly CRYPTO_PAIRS = ['BTCUSD', 'ETHUSD', 'LTCUSD', 'XRPUSD'];

  /**
   * Extract market data from image using Tesseract OCR
   * 
   * Note: In production, this would use Tesseract.js or cloud OCR API
   * For now, we provide a mock implementation that can be replaced
   */
  public async extractFromImage(imageUri: string): Promise<MultiTimeframeExtraction | null> {
    try {
      // In a real implementation, you would:
      // 1. Load image from URI
      // 2. Run Tesseract OCR: const { data } = await Tesseract.recognize(image, 'eng');
      // 3. Parse OCR text for market data
      
      // For now, return mock data structure
      const mockResult = this.generateMockExtraction();
      return mockResult;
    } catch (error) {
      console.error('[OCRService] Error extracting from image:', error);
      return null;
    }
  }

  /**
   * Parse OCR text to extract market data
   */
  public parseOCRText(text: string): MultiTimeframeExtraction | null {
    const lines = text.split('\n').filter(line => line.trim().length > 0);
    
    // Try to identify symbol
    const symbol = this.extractSymbol(text);
    if (!symbol) {
      return null;
    }

    // Extract all timeframes
    const timeframes: ExtractedMarketData[] = [];
    const warnings: string[] = [];

    for (const line of lines) {
      const extracted = this.extractTimeframeData(line, symbol);
      if (extracted) {
        timeframes.push(extracted);
      }
    }

    if (timeframes.length === 0) {
      warnings.push('No valid OHLC data found in screenshot');
      return null;
    }

    const overallConfidence = timeframes.reduce((sum, tf) => sum + tf.confidence, 0) / timeframes.length;

    return {
      symbol,
      extractedAt: Date.now(),
      timeframes,
      overallConfidence,
      warnings,
    };
  }

  /**
   * Extract symbol/pair from text
   */
  private extractSymbol(text: string): string | null {
    const upperText = text.toUpperCase();

    // Check for Forex pairs
    for (const pair of this.FOREX_PAIRS) {
      if (upperText.includes(pair)) {
        return pair;
      }
    }

    // Check for crypto pairs
    for (const pair of this.CRYPTO_PAIRS) {
      if (upperText.includes(pair)) {
        return pair;
      }
    }

    // Try to extract from common patterns like "EUR/USD" or "EUR USD"
    const pairPattern = /([A-Z]{3})[\s\/]([A-Z]{3})/g;
    const match = pairPattern.exec(upperText);
    if (match) {
      return match[1] + match[2];
    }

    return null;
  }

  /**
   * Extract timeframe data from a line of OCR text
   */
  private extractTimeframeData(line: string, symbol: string): ExtractedMarketData | null {
    // Pattern: "1h 1.1050 1.1075 1.1025 1.1060 1250000"
    // Or: "1H Open: 1.1050 High: 1.1075 Low: 1.1025 Close: 1.1060 Vol: 1250000"

    // Try to extract timeframe
    let timeframe: string | null = null;
    for (const tf of this.SUPPORTED_TIMEFRAMES) {
      if (line.toUpperCase().includes(tf.toUpperCase())) {
        timeframe = tf;
        break;
      }
    }

    if (!timeframe) {
      return null;
    }

    // Extract OHLC values
    const numbers = this.extractNumbers(line);
    if (numbers.length < 4) {
      return null;
    }

    const [open, high, low, close, ...rest] = numbers;
    const volume = rest.length > 0 ? rest[0] : 0;

    // Validate OHLC logic
    if (!this.validateOHLC(open, high, low, close)) {
      return null;
    }

    return {
      symbol,
      timeframe,
      open,
      high,
      low,
      close,
      volume,
      timestamp: this.estimateCandleCloseTime(timeframe),
      confidence: this.calculateConfidence(line, { open, high, low, close }),
      rawText: line,
    };
  }

  /**
   * Extract all numbers from text
   */
  private extractNumbers(text: string): number[] {
    const numberPattern = /\d+\.?\d*/g;
    const matches = text.match(numberPattern) || [];
    return matches.map(m => parseFloat(m)).filter(n => !isNaN(n));
  }

  /**
   * Validate OHLC logic
   */
  private validateOHLC(open: number, high: number, low: number, close: number): boolean {
    // High should be >= all others
    if (high < open || high < low || high < close) {
      return false;
    }

    // Low should be <= all others
    if (low > open || low > high || low > close) {
      return false;
    }

    // All values should be positive and reasonable
    if (open <= 0 || high <= 0 || low <= 0 || close <= 0) {
      return false;
    }

    // Reject extreme outliers (e.g., OCR misread)
    const range = high - low;
    const avgPrice = (open + high + low + close) / 4;
    if (range / avgPrice > 0.5) {
      // More than 50% range is suspicious
      return false;
    }

    return true;
  }

  /**
   * Calculate confidence score for extracted data
   */
  private calculateConfidence(line: string, ohlc: any): number {
    let confidence = 0.5; // Base confidence

    // Check if line contains common keywords
    const keywords = ['open', 'high', 'low', 'close', 'volume', 'vol'];
    const keywordCount = keywords.filter(kw => line.toLowerCase().includes(kw)).length;
    confidence += keywordCount * 0.05;

    // Check if numbers are properly formatted (decimal points)
    const decimalCount = (line.match(/\./g) || []).length;
    if (decimalCount >= 3) {
      confidence += 0.1;
    }

    // Check for volume (usually much larger number)
    if (line.match(/\d{6,}/)) {
      confidence += 0.1;
    }

    return Math.min(confidence, 1);
  }

  /**
   * Estimate candle close time based on timeframe
   */
  private estimateCandleCloseTime(timeframe: string): number {
    const now = Date.now();
    const timeframeMs: Record<string, number> = {
      '1m': 60 * 1000,
      '5m': 5 * 60 * 1000,
      '15m': 15 * 60 * 1000,
      '30m': 30 * 60 * 1000,
      '1h': 60 * 60 * 1000,
      '4h': 4 * 60 * 60 * 1000,
      '1d': 24 * 60 * 60 * 1000,
      '1w': 7 * 24 * 60 * 60 * 1000,
      '1M': 30 * 24 * 60 * 60 * 1000,
    };

    const ms = timeframeMs[timeframe] || 60 * 1000;
    return now - (now % ms);
  }

  /**
   * Validate and correct extracted data
   */
  public validateExtraction(extraction: MultiTimeframeExtraction): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Check symbol
    if (!extraction.symbol) {
      errors.push('Symbol not identified');
    }

    // Check timeframes
    if (extraction.timeframes.length === 0) {
      errors.push('No timeframe data extracted');
    }

    // Check confidence
    if (extraction.overallConfidence < 0.3) {
      errors.push(`Low confidence score: ${extraction.overallConfidence.toFixed(2)}`);
    }

    // Validate each timeframe
    for (const tf of extraction.timeframes) {
      if (tf.confidence < 0.2) {
        errors.push(`Low confidence for ${tf.timeframe}: ${tf.confidence.toFixed(2)}`);
      }

      if (tf.volume < 0) {
        errors.push(`Invalid volume for ${tf.timeframe}: ${tf.volume}`);
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
    };
  }

  /**
   * Generate mock extraction for testing
   */
  private generateMockExtraction(): MultiTimeframeExtraction {
    const now = Date.now();
    return {
      symbol: 'EURUSD',
      extractedAt: now,
      timeframes: [
        {
          symbol: 'EURUSD',
          timeframe: '1h',
          open: 1.1050,
          high: 1.1075,
          low: 1.1025,
          close: 1.1060,
          volume: 1250000,
          timestamp: now - (60 * 60 * 1000),
          confidence: 0.85,
          rawText: '1h 1.1050 1.1075 1.1025 1.1060 1250000',
        },
        {
          symbol: 'EURUSD',
          timeframe: '4h',
          open: 1.1000,
          high: 1.1100,
          low: 1.0950,
          close: 1.1060,
          volume: 5000000,
          timestamp: now - (4 * 60 * 60 * 1000),
          confidence: 0.80,
          rawText: '4h 1.1000 1.1100 1.0950 1.1060 5000000',
        },
      ],
      overallConfidence: 0.825,
      warnings: [],
    };
  }
}

/**
 * Factory function to create OCR service
 */
export function createOCRService(): OCRService {
  return new OCRService();
}
