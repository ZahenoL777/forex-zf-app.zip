# Forex ZF-Core Analyzer — Mobile App Interface Design

## Overview

**Forex ZF-Core Analyzer** adalah aplikasi mobile untuk analisis pasar Forex & BTC berbasis konsep Zuhri Formalism (ZF-Core). Aplikasi dirancang untuk trader profesional yang membutuhkan analisis real-time dengan presisi tinggi, sinkronisasi multi-market, dan visualisasi entry/SL/TP berbasis algoritma ZF-Core.

**Target Platform:** iOS & Android (portrait orientation, one-handed usage)
**Design Philosophy:** Clean, data-dense, professional — seperti aplikasi trading tier-1

---

## Screen List

### 1. **Dashboard (Home)**
- **Purpose:** Tampilan utama dengan overview semua pairs yang dipantau
- **Content:**
  - ZF-Score gauge/indicator untuk top 5 pairs dengan status kritis
  - Live price ticker untuk Forex major pairs (EUR/USD, GBP/USD, USD/JPY, etc.)
  - Live price ticker untuk BTC/USD
  - Quick stats: Total pairs monitored, Active anomalies, Circuit breaker status
  - Market status indicator (laminar/anomalous)
- **Interactions:**
  - Tap pada pair → Detail screen
  - Swipe untuk refresh data real-time
  - Settings icon → Settings screen

### 2. **Pair Detail Screen**
- **Purpose:** Analisis mendalam untuk satu pair tertentu
- **Content:**
  - Price chart dengan candlestick (1m, 5m, 15m, 1h, 4h, 1d)
  - Real-time ZF-Score gauge (0-1 scale dengan color coding: green <0.5, yellow 0.5-0.8, red >0.8)
  - Topological Drift (D_res) value & trend
  - Resonance Decay prediction (Decay_t)
  - Inflection Point indicator (d²P/dt² status)
  - Order Book depth visualization (Bid/Ask spread)
  - Liquidity Clustering heatmap
  - Entry signal indicator (Resonance Re-entry status)
  - Dynamic Stop-Loss level (3-sigma threshold)
  - Taking Profit level (Decay inflection point)
- **Interactions:**
  - Tap chart untuk zoom/pan
  - Timeframe selector (1m, 5m, 15m, 1h, 4h, 1d)
  - "Analyze Screenshot" button → Screenshot input screen
  - "Set Alert" button → Alert configuration
  - "Execute Trade" button → Trade execution sheet

### 3. **Screenshot Input Screen**
- **Purpose:** Upload & OCR multi-timeframe market data dari foto
- **Content:**
  - Camera/gallery picker button
  - Image preview area
  - OCR processing indicator
  - Extracted data table (timeframe, OHLC values, volume)
  - Manual correction fields (untuk nilai yang tidak terbaca dengan akurat)
  - "Analyze" button → trigger ZF-Core calculation
- **Interactions:**
  - Upload foto → OCR extraction
  - Edit extracted values jika diperlukan
  - Confirm → hasil analisis ditampilkan di "Analysis Result" screen

### 4. **Analysis Result Screen**
- **Purpose:** Tampilkan hasil analisis ZF-Core dalam format visual
- **Content:**
  - Generated image dengan:
    * Chart dengan support/resistance lines
    * Entry point (Resonance Re-entry)
    * Stop-Loss level (3-sigma threshold)
    * Taking Profit level (Decay inflection)
    * ZF-Score value & interpretation
    * Topological Drift percentage
    * Liquidity status (void/normal/clustering)
  - Rekomendasi aksi (Waspada/Pertahanan Sistemik/Eksekusi)
  - Confidence level (berdasarkan data quality)
  - "Save Analysis" button → simpan ke history
  - "Share" button → bagikan hasil ke clipboard/social
  - "Execute Trade" button → trade execution

### 5. **Broker API Manager Screen**
- **Purpose:** Kelola API keys dari berbagai broker secara aman
- **Content:**
  - List broker yang tersedia (Binance, Kraken, OANDA, IC Markets, etc.)
  - Add/Edit/Delete API key untuk setiap broker
  - Secure storage indicator (encrypted)
  - Test connection button untuk setiap broker
  - Last sync timestamp
- **Interactions:**
  - Tap broker → detail screen untuk edit API key
  - Add new broker → form untuk input API key & secret
  - Delete broker → confirmation dialog
  - Test connection → status indicator

### 6. **Trade Execution Sheet**
- **Purpose:** Konfirmasi & eksekusi trade berdasarkan analisis ZF-Core
- **Content:**
  - Pair & direction (Buy/Sell)
  - Entry price (dari analisis)
  - Stop-Loss level (3-sigma)
  - Taking Profit level (Decay inflection)
  - Position size calculator
  - Risk/Reward ratio display
  - Broker selector (dari API Manager)
  - Confirmation button
- **Interactions:**
  - Adjust entry/SL/TP jika diperlukan
  - Calculate position size based on risk %
  - Confirm → execute trade via broker API
  - Cancel → kembali ke previous screen

### 7. **Session Memory / History Screen**
- **Purpose:** Lihat riwayat analisis & data sesi sebelumnya
- **Content:**
  - List analisis yang telah disimpan (dengan timestamp)
  - Filter by pair, date range, status
  - Untuk setiap item: pair, ZF-Score, entry/SL/TP, result (win/loss)
  - Comparison view: sesi sebelumnya vs sesi saat ini
  - Export data button (CSV/JSON)
- **Interactions:**
  - Tap item → detail view dengan chart & analisis
  - Delete item → confirmation
  - Export → save to file

### 8. **Settings Screen**
- **Purpose:** Konfigurasi aplikasi & preferensi pengguna
- **Content:**
  - Theme (Light/Dark)
  - Notification preferences (alert untuk ZF-Score >0.8, circuit breaker, etc.)
  - Data refresh interval (real-time, 5s, 10s, 30s)
  - Default timeframe preference
  - Risk management settings (default position size, max leverage)
  - Circuit breaker threshold (default 0.99)
  - Mode Dingin settings (lockout duration)
  - About & version info
- **Interactions:**
  - Toggle settings
  - Save preferences

### 9. **Alerts / Notifications Screen**
- **Purpose:** Manage & view real-time alerts
- **Content:**
  - Active alerts list
  - Alert type: ZF-Score threshold, Liquidity Void, Inflection Point, Circuit Breaker
  - Timestamp & pair
  - Action buttons (Dismiss, View Analysis, Execute Trade)
- **Interactions:**
  - Tap alert → go to pair detail screen
  - Dismiss alert
  - Configure alert rules

---

## Primary Content & Functionality by Screen

| Screen | Primary Data | Key Functionality |
|--------|-------------|-------------------|
| Dashboard | ZF-Scores, live prices, market status | Monitor, quick access to pairs |
| Pair Detail | Chart, ZF metrics, order book | Analyze, set alerts, execute trade |
| Screenshot Input | Image, OCR extracted data | Upload, extract, correct data |
| Analysis Result | Generated image, ZF analysis | View, save, share, execute |
| Broker API Manager | API keys, broker list | Add/edit/delete keys, test connection |
| Trade Execution | Entry/SL/TP, position size | Confirm & execute trade |
| Session Memory | Historical data, comparisons | Review, export, compare sessions |
| Settings | User preferences, thresholds | Configure app behavior |
| Alerts | Real-time notifications | Manage, respond to alerts |

---

## Key User Flows

### Flow 1: Monitor & Analyze a Pair
1. User opens Dashboard
2. Sees ZF-Scores for top pairs
3. Taps on EUR/USD (ZF-Score 0.85 = high risk)
4. Views Pair Detail screen with chart & metrics
5. Sees Entry signal + SL/TP levels
6. Decides to execute trade → Trade Execution sheet
7. Confirms & executes via broker API

### Flow 2: Upload & Analyze Screenshot
1. User has multi-timeframe screenshot from trading platform
2. Opens Screenshot Input screen
3. Uploads image from gallery
4. OCR extracts OHLC data from multiple timeframes
5. User reviews & corrects extracted values if needed
6. Taps "Analyze" → ZF-Core calculation runs
7. Views Analysis Result with generated image (entry/SL/TP)
8. Saves analysis to history or executes trade

### Flow 3: Manage Broker API Keys
1. User opens Broker API Manager
2. Taps "Add Broker" → selects Binance
3. Enters API key & secret
4. Taps "Test Connection" → success indicator
5. API key stored securely (encrypted)
6. Can now execute trades via this broker

### Flow 4: Circuit Breaker Activation
1. Real-time data shows ZF-Score > 0.99 for multiple pairs
2. App triggers Circuit Breaker
3. All positions auto-liquidated
4. User receives notification
5. Interface locked for 30 minutes (Mode Dingin)
6. User can view logs but cannot trade
7. After 30 min, interface unlocked

---

## Color Choices

**Brand Colors (Professional Trading App):**
- **Primary:** `#0a7ea4` (Teal/Blue — trust, stability)
- **Background:** `#ffffff` (Light) / `#151718` (Dark)
- **Surface:** `#f5f5f5` (Light) / `#1e2022` (Dark)
- **Foreground:** `#11181C` (Light) / `#ECEDEE` (Dark)
- **Muted:** `#687076` (Light) / `#9BA1A6` (Dark)
- **Border:** `#E5E7EB` (Light) / `#334155` (Dark)

**Status Colors:**
- **Success (ZF-Score < 0.5):** `#22C55E` (Green)
- **Warning (ZF-Score 0.5-0.8):** `#F59E0B` (Amber)
- **Error (ZF-Score > 0.8):** `#EF4444` (Red)
- **Critical (ZF-Score > 0.99):** `#DC2626` (Dark Red)

**Chart Colors:**
- **Bullish candle:** `#22C55E` (Green)
- **Bearish candle:** `#EF4444` (Red)
- **Support line:** `#3B82F6` (Blue)
- **Resistance line:** `#F59E0B` (Amber)
- **Entry point:** `#10B981` (Emerald)
- **Stop-Loss:** `#EF4444` (Red)
- **Taking Profit:** `#22C55E` (Green)

---

## Layout Principles

1. **Mobile Portrait (9:16):** All screens optimized for portrait orientation
2. **One-Handed Usage:** Critical buttons (execute, confirm) positioned in thumb-reachable zone (bottom half)
3. **Data Density:** Show essential metrics without overwhelming; use tabs/collapsible sections for details
4. **Real-Time Responsiveness:** Charts & metrics update smoothly without jarring jumps
5. **Safe Area Handling:** Content respects notch & home indicator on iPhone X+
6. **Tab Bar Navigation:** Bottom tab bar for main sections (Dashboard, Pairs, OCR, History, Settings)

---

## Next Steps

1. Implement core ZF-Core calculation engine
2. Set up real-time data sync from Forex/BTC APIs
3. Build UI components for each screen
4. Integrate OCR for screenshot analysis
5. Implement secure broker API key management
6. Add visualization engine for analysis results
7. Test end-to-end flows
8. Deploy to Expo Go for mobile testing
