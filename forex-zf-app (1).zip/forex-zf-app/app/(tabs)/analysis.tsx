import { ScrollView, Text, View, Pressable, ActivityIndicator } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import { useState } from 'react';

/**
 * Analysis Screen - OCR Input & Results
 * 
 * Features:
 * - Screenshot upload (camera/gallery)
 * - OCR processing with Tesseract.js
 * - OHLC data extraction
 * - ZF-Core analysis results
 * - Entry/SL/TP visualization
 */

interface AnalysisResult {
  symbol: string;
  timeframe: string;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  zfScore: number;
  recommendation: string;
  confidence: number;
}

export default function AnalysisScreen() {
  const colors = useColors();
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [ocrText, setOcrText] = useState('');

  const handleUploadScreenshot = async () => {
    setIsProcessing(true);
    try {
      // Simulate OCR processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Mock analysis result
      const mockResult: AnalysisResult = {
        symbol: 'EURUSD',
        timeframe: '1h',
        entry: 1.1050,
        stopLoss: 1.1025,
        takeProfit: 1.1100,
        zfScore: 0.72,
        recommendation: 'Execute',
        confidence: 0.85,
      };

      setAnalysisResult(mockResult);
      setOcrText('EURUSD 1h\nOpen: 1.1050\nHigh: 1.1075\nLow: 1.1025\nClose: 1.1060\nVolume: 1250000');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClearResult = () => {
    setAnalysisResult(null);
    setOcrText('');
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-6 pb-8">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Analysis</Text>
            <Text className="text-sm text-muted">Upload screenshot & extract OHLC data</Text>
          </View>

          {!analysisResult ? (
            <>
              {/* Upload Section */}
              <View className="gap-4">
                <Text className="text-lg font-semibold text-foreground">Step 1: Upload Screenshot</Text>

                <Pressable
                  onPress={handleUploadScreenshot}
                  disabled={isProcessing}
                  className="bg-primary rounded-lg p-6 items-center active:opacity-80 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <ActivityIndicator color={colors.background} size="large" />
                      <Text className="text-white font-semibold mt-3">Processing...</Text>
                    </>
                  ) : (
                    <>
                      <Text className="text-3xl mb-2">📸</Text>
                      <Text className="text-white font-semibold">Upload Screenshot</Text>
                      <Text className="text-white text-xs mt-1 opacity-80">Camera or Gallery</Text>
                    </>
                  )}
                </Pressable>

                <View className="flex-row gap-2">
                  <View className="flex-1 bg-surface rounded-lg p-3 border border-border">
                    <Text className="text-xs text-muted mb-1">Supported Formats</Text>
                    <Text className="text-sm font-semibold text-foreground">PNG, JPG, WebP</Text>
                  </View>
                  <View className="flex-1 bg-surface rounded-lg p-3 border border-border">
                    <Text className="text-xs text-muted mb-1">Max Size</Text>
                    <Text className="text-sm font-semibold text-foreground">10 MB</Text>
                  </View>
                </View>
              </View>

              {/* Info Section */}
              <View className="bg-surface rounded-lg p-4 border border-border gap-3">
                <Text className="font-semibold text-foreground">💡 Tips for Best Results</Text>
                <Text className="text-sm text-muted leading-relaxed">
                  • Capture clear, high-contrast chart screenshots{'\n'}
                  • Include OHLC values and volume data{'\n'}
                  • Ensure text is readable and not blurry{'\n'}
                  • Use portrait orientation for better accuracy
                </Text>
              </View>
            </>
          ) : (
            <>
              {/* Results Section */}
              <View className="gap-4">
                <View className="flex-row justify-between items-center">
                  <Text className="text-lg font-semibold text-foreground">Analysis Results</Text>
                  <Pressable onPress={handleClearResult} className="active:opacity-70">
                    <Text className="text-sm text-primary font-medium">New Analysis</Text>
                  </Pressable>
                </View>

                {/* Symbol & Timeframe */}
                <View className="bg-surface rounded-lg p-4 border border-border">
                  <Text className="text-xs text-muted mb-2">Pair & Timeframe</Text>
                  <Text className="text-2xl font-bold text-foreground">
                    {analysisResult.symbol} • {analysisResult.timeframe}
                  </Text>
                </View>

                {/* ZF-Score */}
                <View className="bg-surface rounded-lg p-4 border border-border">
                  <Text className="text-xs text-muted mb-2">ZF-Score</Text>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-3xl font-bold text-primary">
                      {analysisResult.zfScore.toFixed(2)}
                    </Text>
                    <View className="flex-1 h-2 bg-border rounded-full ml-4 overflow-hidden">
                      <View
                        className="h-full rounded-full"
                        style={{
                          width: `${(analysisResult.zfScore / 1) * 100}%`,
                          backgroundColor: analysisResult.zfScore > 0.8 ? colors.error : colors.success,
                        }}
                      />
                    </View>
                  </View>
                </View>

                {/* Trading Levels */}
                <View className="gap-3">
                  <Text className="text-sm font-semibold text-foreground">Trading Levels</Text>

                  <View className="bg-surface rounded-lg p-4 border border-border gap-3">
                    <View className="flex-row justify-between items-center">
                      <Text className="text-sm text-muted">Entry Point</Text>
                      <Text className="text-lg font-bold text-primary">
                        {analysisResult.entry.toFixed(5)}
                      </Text>
                    </View>
                    <View className="h-px bg-border" />
                    <View className="flex-row justify-between items-center">
                      <Text className="text-sm text-muted">Stop Loss</Text>
                      <Text className="text-lg font-bold text-error">
                        {analysisResult.stopLoss.toFixed(5)}
                      </Text>
                    </View>
                    <View className="h-px bg-border" />
                    <View className="flex-row justify-between items-center">
                      <Text className="text-sm text-muted">Take Profit</Text>
                      <Text className="text-lg font-bold text-success">
                        {analysisResult.takeProfit.toFixed(5)}
                      </Text>
                    </View>
                  </View>
                </View>

                {/* Risk/Reward */}
                <View className="bg-surface rounded-lg p-4 border border-border">
                  <Text className="text-xs text-muted mb-2">Risk/Reward Ratio</Text>
                  <Text className="text-2xl font-bold text-foreground">
                    {((analysisResult.takeProfit - analysisResult.entry) / (analysisResult.entry - analysisResult.stopLoss)).toFixed(2)}
                    :1
                  </Text>
                </View>

                {/* Recommendation */}
                <View
                  className="rounded-lg p-4 border-l-4"
                  style={{ borderLeftColor: analysisResult.recommendation === 'Execute' ? colors.success : colors.warning }}
                >
                  <Text className="text-xs text-muted mb-1">Recommendation</Text>
                  <Text className="text-lg font-bold text-foreground">
                    {analysisResult.recommendation}
                  </Text>
                  <Text className="text-xs text-muted mt-2">
                    Confidence: {(analysisResult.confidence * 100).toFixed(0)}%
                  </Text>
                </View>

                {/* OCR Text */}
                {ocrText && (
                  <View className="bg-surface rounded-lg p-4 border border-border">
                    <Text className="text-xs text-muted mb-2 font-semibold">Extracted OCR Text</Text>
                    <Text className="text-xs text-foreground font-mono leading-relaxed">
                      {ocrText}
                    </Text>
                  </View>
                )}

                {/* Action Buttons */}
                <View className="flex-row gap-3">
                  <Pressable className="flex-1 bg-primary rounded-lg p-4 items-center active:opacity-80">
                    <Text className="text-white font-semibold">📊 Export</Text>
                  </Pressable>
                  <Pressable className="flex-1 bg-surface border border-border rounded-lg p-4 items-center active:opacity-70">
                    <Text className="text-foreground font-semibold">📤 Share</Text>
                  </Pressable>
                </View>
              </View>
            </>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
