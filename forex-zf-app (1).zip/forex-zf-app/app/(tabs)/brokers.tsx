import { ScrollView, Text, View, Pressable, TextInput } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import { useState } from 'react';

/**
 * Brokers Screen - API Key Management
 * 
 * Features:
 * - Add/edit/delete broker configurations
 * - Secure API key storage (encrypted)
 * - Connection testing
 * - Trade execution interface
 */

interface BrokerConfig {
  id: string;
  name: string;
  apiKey: string;
  apiSecret: string;
  connected: boolean;
}

export default function BrokersScreen() {
  const colors = useColors();
  const [brokers, setBrokers] = useState<BrokerConfig[]>([
    {
      id: '1',
      name: 'Binance',
      apiKey: '••••••••••••••••••••',
      apiSecret: '••••••••••••••••••••',
      connected: true,
    },
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', apiKey: '', apiSecret: '' });

  const handleAddBroker = () => {
    if (formData.name && formData.apiKey && formData.apiSecret) {
      const newBroker: BrokerConfig = {
        id: Date.now().toString(),
        name: formData.name,
        apiKey: '••••••••••••••••••••',
        apiSecret: '••••••••••••••••••••',
        connected: false,
      };
      setBrokers([...brokers, newBroker]);
      setFormData({ name: '', apiKey: '', apiSecret: '' });
      setShowAddForm(false);
    }
  };

  const handleTestConnection = (brokerId: string) => {
    setBrokers(
      brokers.map(b =>
        b.id === brokerId ? { ...b, connected: !b.connected } : b
      )
    );
  };

  const handleDeleteBroker = (brokerId: string) => {
    setBrokers(brokers.filter(b => b.id !== brokerId));
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-6 pb-8">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Brokers</Text>
            <Text className="text-sm text-muted">Manage API keys & connections</Text>
          </View>

          {/* Active Brokers */}
          <View className="gap-3">
            <View className="flex-row justify-between items-center">
              <Text className="text-lg font-semibold text-foreground">Connected Brokers</Text>
              <Pressable
                onPress={() => setShowAddForm(!showAddForm)}
                className="bg-primary rounded-lg px-3 py-2 active:opacity-80"
              >
                <Text className="text-white text-sm font-semibold">+ Add</Text>
              </Pressable>
            </View>

            {brokers.length > 0 ? (
              brokers.map(broker => (
                <View
                  key={broker.id}
                  className="bg-surface rounded-lg p-4 border border-border gap-3"
                >
                  <View className="flex-row justify-between items-center">
                    <View className="flex-1">
                      <Text className="text-base font-semibold text-foreground">
                        {broker.name}
                      </Text>
                      <View className="flex-row items-center gap-2 mt-1">
                        <View
                          className="w-2 h-2 rounded-full"
                          style={{
                            backgroundColor: broker.connected ? colors.success : colors.muted,
                          }}
                        />
                        <Text className="text-xs text-muted">
                          {broker.connected ? 'Connected' : 'Disconnected'}
                        </Text>
                      </View>
                    </View>
                    <Text className="text-xs text-muted">{broker.apiKey}</Text>
                  </View>

                  <View className="flex-row gap-2">
                    <Pressable
                      onPress={() => handleTestConnection(broker.id)}
                      className="flex-1 bg-primary rounded-lg p-2 items-center active:opacity-80"
                    >
                      <Text className="text-white text-xs font-semibold">
                        {broker.connected ? 'Disconnect' : 'Connect'}
                      </Text>
                    </Pressable>
                    <Pressable
                      onPress={() => handleDeleteBroker(broker.id)}
                      className="flex-1 bg-error rounded-lg p-2 items-center active:opacity-80"
                    >
                      <Text className="text-white text-xs font-semibold">Delete</Text>
                    </Pressable>
                  </View>
                </View>
              ))
            ) : (
              <View className="bg-surface rounded-lg p-4 items-center border border-border">
                <Text className="text-sm text-muted">No brokers configured</Text>
              </View>
            )}
          </View>

          {/* Add Broker Form */}
          {showAddForm && (
            <View className="bg-surface rounded-lg p-4 border border-border gap-3">
              <Text className="font-semibold text-foreground">Add New Broker</Text>

              <View className="gap-2">
                <Text className="text-xs text-muted">Broker Name</Text>
                <TextInput
                  placeholder="e.g., Binance, OANDA, Kraken"
                  placeholderTextColor={colors.muted}
                  value={formData.name}
                  onChangeText={text => setFormData({ ...formData, name: text })}
                  className="bg-background rounded-lg px-3 py-2 text-foreground border border-border"
                />
              </View>

              <View className="gap-2">
                <Text className="text-xs text-muted">API Key</Text>
                <TextInput
                  placeholder="Enter API key"
                  placeholderTextColor={colors.muted}
                  value={formData.apiKey}
                  onChangeText={text => setFormData({ ...formData, apiKey: text })}
                  secureTextEntry
                  className="bg-background rounded-lg px-3 py-2 text-foreground border border-border"
                />
              </View>

              <View className="gap-2">
                <Text className="text-xs text-muted">API Secret</Text>
                <TextInput
                  placeholder="Enter API secret"
                  placeholderTextColor={colors.muted}
                  value={formData.apiSecret}
                  onChangeText={text => setFormData({ ...formData, apiSecret: text })}
                  secureTextEntry
                  className="bg-background rounded-lg px-3 py-2 text-foreground border border-border"
                />
              </View>

              <View className="flex-row gap-2 mt-2">
                <Pressable
                  onPress={handleAddBroker}
                  className="flex-1 bg-primary rounded-lg p-3 items-center active:opacity-80"
                >
                  <Text className="text-white font-semibold">Add Broker</Text>
                </Pressable>
                <Pressable
                  onPress={() => setShowAddForm(false)}
                  className="flex-1 bg-border rounded-lg p-3 items-center active:opacity-70"
                >
                  <Text className="text-foreground font-semibold">Cancel</Text>
                </Pressable>
              </View>
            </View>
          )}

          {/* Security Info */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-2">
            <Text className="font-semibold text-foreground">🔐 Security</Text>
            <Text className="text-xs text-muted leading-relaxed">
              All API keys are encrypted with AES-256 and stored securely. Keys are never transmitted or logged.
            </Text>
          </View>

          {/* Supported Brokers */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <Text className="font-semibold text-foreground">Supported Brokers</Text>
            <View className="gap-2">
              {['Binance', 'OANDA', 'Kraken', 'IC Markets'].map(broker => (
                <View key={broker} className="flex-row items-center gap-2">
                  <View className="w-2 h-2 rounded-full bg-primary" />
                  <Text className="text-sm text-muted">{broker}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
