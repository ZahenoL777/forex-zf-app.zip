import { ScrollView, Text, View, Pressable, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import { useState, useEffect } from 'react';

/**
 * Dashboard Screen - Main entry point for Forex ZF-Core Analyzer
 * 
 * Displays:
 * - Market overview with ZF-Scores
 * - Live price tickers
 * - Recent alerts
 * - Quick actions
 */

interface MarketPair {
  symbol: string;
  price: number;
  change: number;
  zfScore: number;
  status: 'normal' | 'caution' | 'critical';
}

interface Alert {
  id: string;
  type: string;
  symbol: string;
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: number;
}

export default function DashboardScreen() {
  const colors = useColors();
  const [pairs, setPairs] = useState<MarketPair[]>([
    { symbol: 'EURUSD', price: 1.1050, change: 0.25, zfScore: 0.45, status: 'normal' },
    { symbol: 'GBPUSD', price: 1.2750, change: -0.15, zfScore: 0.72, status: 'caution' },
    { symbol: 'USDJPY', price: 149.50, change: 0.50, zfScore: 0.85, status: 'critical' },
    { symbol: 'BTCUSD', price: 45250, change: 1.25, zfScore: 0.38, status: 'normal' },
    { symbol: 'ETHUSD', price: 2450, change: -0.75, zfScore: 0.65, status: 'caution' },
  ]);

  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: '1',
      type: 'ZF_SCORE_CRITICAL',
      symbol: 'USDJPY',
      message: 'Critical ZF-Score detected',
      severity: 'critical',
      timestamp: Date.now() - 300000,
    },
    {
      id: '2',
      type: 'INFLECTION_POINT',
      symbol: 'EURUSD',
      message: 'Inflection point detected',
      severity: 'medium',
      timestamp: Date.now() - 600000,
    },
  ]);

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'normal':
        return colors.success;
      case 'caution':
        return colors.warning;
      case 'critical':
        return colors.error;
      default:
        return colors.muted;
    }
  };

  const getSeverityColor = (severity: string): string => {
    switch (severity) {
      case 'critical':
        return colors.error;
      case 'high':
        return colors.warning;
      case 'medium':
        return colors.warning;
      default:
        return colors.muted;
    }
  };

  const formatTime = (timestamp: number): string => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return 'just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-6 pb-8">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">ZF-Core Analyzer</Text>
            <Text className="text-sm text-muted">Real-time Forex & BTC Analysis</Text>
          </View>

          {/* Market Overview Stats */}
          <View className="flex-row gap-3">
            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1">Monitoring</Text>
              <Text className="text-2xl font-bold text-foreground">{pairs.length}</Text>
              <Text className="text-xs text-muted mt-1">Pairs</Text>
            </View>
            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1">Critical</Text>
              <Text className="text-2xl font-bold text-error">
                {pairs.filter(p => p.status === 'critical').length}
              </Text>
              <Text className="text-xs text-muted mt-1">Alerts</Text>
            </View>
            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1">Avg ZF-Score</Text>
              <Text className="text-2xl font-bold text-primary">
                {(pairs.reduce((sum, p) => sum + p.zfScore, 0) / pairs.length).toFixed(2)}
              </Text>
              <Text className="text-xs text-muted mt-1">Score</Text>
            </View>
          </View>

          {/* Market Pairs List */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Market Pairs</Text>
            {pairs.map(pair => (
              <Pressable
                key={pair.symbol}
                className="bg-surface rounded-lg p-4 border border-border active:opacity-70"
              >
                <View className="flex-row justify-between items-center mb-2">
                  <View className="flex-1">
                    <Text className="text-base font-semibold text-foreground">{pair.symbol}</Text>
                    <Text className="text-xs text-muted mt-1">
                      {pair.change > 0 ? '+' : ''}{pair.change.toFixed(2)}%
                    </Text>
                  </View>
                  <View className="items-end">
                    <Text className="text-base font-bold text-foreground">
                      {pair.price.toFixed(pair.symbol.includes('BTC') ? 0 : 4)}
                    </Text>
                    <View className="flex-row items-center gap-1 mt-1">
                      <View
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: getStatusColor(pair.status) }}
                      />
                      <Text className="text-xs text-muted">ZF: {pair.zfScore.toFixed(2)}</Text>
                    </View>
                  </View>
                </View>
                <View className="w-full h-1 bg-border rounded-full overflow-hidden">
                  <View
                    className="h-full rounded-full"
                    style={{
                      width: `${(pair.zfScore / 1) * 100}%`,
                      backgroundColor: getStatusColor(pair.status),
                    }}
                  />
                </View>
              </Pressable>
            ))}
          </View>

          {/* Recent Alerts */}
          <View className="gap-3">
            <View className="flex-row justify-between items-center">
              <Text className="text-lg font-semibold text-foreground">Recent Alerts</Text>
              <Pressable className="active:opacity-70">
                <Text className="text-sm text-primary font-medium">View All</Text>
              </Pressable>
            </View>
            {alerts.length > 0 ? (
              alerts.slice(0, 3).map(alert => (
                <View
                  key={alert.id}
                  className="bg-surface rounded-lg p-3 border-l-4 flex-row items-start gap-3"
                  style={{ borderLeftColor: getSeverityColor(alert.severity) }}
                >
                  <View className="flex-1">
                    <Text className="text-sm font-semibold text-foreground">
                      {alert.symbol} • {alert.type.replace(/_/g, ' ')}
                    </Text>
                    <Text className="text-xs text-muted mt-1">{alert.message}</Text>
                    <Text className="text-xs text-muted mt-1">{formatTime(alert.timestamp)}</Text>
                  </View>
                  <View
                    className="w-2 h-2 rounded-full mt-1"
                    style={{ backgroundColor: getSeverityColor(alert.severity) }}
                  />
                </View>
              ))
            ) : (
              <View className="bg-surface rounded-lg p-4 items-center">
                <Text className="text-sm text-muted">No alerts</Text>
              </View>
            )}
          </View>

          {/* Quick Actions */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Quick Actions</Text>
            <View className="flex-row gap-3">
              <Pressable className="flex-1 bg-primary rounded-lg p-4 items-center active:opacity-80">
                <Text className="text-white font-semibold">📊 Analyze</Text>
              </Pressable>
              <Pressable className="flex-1 bg-surface border border-border rounded-lg p-4 items-center active:opacity-70">
                <Text className="text-foreground font-semibold">📸 OCR</Text>
              </Pressable>
            </View>
            <View className="flex-row gap-3">
              <Pressable className="flex-1 bg-surface border border-border rounded-lg p-4 items-center active:opacity-70">
                <Text className="text-foreground font-semibold">⚙️ Settings</Text>
              </Pressable>
              <Pressable className="flex-1 bg-surface border border-border rounded-lg p-4 items-center active:opacity-70">
                <Text className="text-foreground font-semibold">🔑 Brokers</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
