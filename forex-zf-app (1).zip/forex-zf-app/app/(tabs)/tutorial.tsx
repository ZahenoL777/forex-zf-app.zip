/**
 * Tutorial/Onboarding Screen
 * 
 * Comprehensive guide on how to use the Forex ZF-Core Analyzer
 */

import { ScrollView, Text, View, TouchableOpacity, Linking } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';

interface TutorialSection {
  title: string;
  icon: string;
  content: string[];
  tips?: string[];
}

const TUTORIAL_SECTIONS: TutorialSection[] = [
  {
    title: 'Getting Started',
    icon: '🚀',
    content: [
      '1. Launch the app and navigate to the Dashboard tab',
      '2. You will see real-time ZF-Scores for 5 major Forex pairs',
      '3. Each pair shows: current price, 24h change, and ZF-Score (0-1 scale)',
      '4. Green = stable (ZF < 0.5), Yellow = caution (0.5-0.8), Red = critical (>0.8)',
    ],
    tips: [
      'Monitor the "Recent Alerts" section for market anomalies',
      'Check "Critical Alerts" count at the top for urgent signals',
    ],
  },
  {
    title: 'Understanding ZF-Score',
    icon: '📊',
    content: [
      'ZF-Score measures market stability (0 = stable, 1 = critical)',
      'Calculated from: Topological Drift + Liquidity Analysis + Decay Prediction',
      'Score > 0.8 = High probability of reversal or structural break',
      'Score > 0.99 = Circuit breaker triggers (automatic trading halt)',
    ],
    tips: [
      'Use ZF-Score to identify entry/exit opportunities',
      'Combine with Support/Resistance levels for better accuracy',
      'Higher scores = higher risk but higher reward potential',
    ],
  },
  {
    title: 'Screenshot OCR Analysis',
    icon: '📸',
    content: [
      '1. Go to Analysis tab and tap "OCR" button',
      '2. Take a screenshot of your chart (MT4, TradingView, etc.)',
      '3. App automatically extracts OHLC data from multiple timeframes',
      '4. Review extracted data and correct any OCR errors manually',
      '5. Tap "Analyze" to generate ZF-Core analysis',
    ],
    tips: [
      'Ensure chart is clear and well-lit for best OCR accuracy',
      'Include timeframe label in screenshot (1h, 4h, 1d, etc.)',
      'Supported formats: EURUSD, GBPUSD, BTCUSD, etc.',
      'OCR confidence > 0.85 is recommended for trading decisions',
    ],
  },
  {
    title: 'Analysis Results',
    icon: '📈',
    content: [
      'After analysis, you get:',
      '• Entry Price: Optimal entry based on ZF-Core calculation',
      '• Stop-Loss: 3-sigma threshold for risk management',
      '• Take-Profit: Decay inflection point for profit target',
      '• Support/Resistance: Key levels from price action',
      '• ZF-Score: Current market condition indicator',
    ],
    tips: [
      'Entry price is calculated from pure resonance price',
      'SL is 3 standard deviations below entry (risk limit)',
      'TP is where momentum exhaustion is predicted',
      'Export results as image for record-keeping',
    ],
  },
  {
    title: 'Broker Integration',
    icon: '🔌',
    content: [
      '1. Go to Brokers tab',
      '2. Select your broker (Binance, OANDA, Kraken, IC Markets)',
      '3. Enter API Key and Secret (encrypted storage)',
      '4. Test connection to verify credentials',
      '5. Once connected, you can execute trades directly from app',
    ],
    tips: [
      'API keys are encrypted with AES-256 (military-grade)',
      'Never share your API Secret with anyone',
      'Use read-only API keys for safety if available',
      'Test connection before using for live trading',
    ],
  },
  {
    title: 'Real-Time Alerts',
    icon: '🔔',
    content: [
      'App sends push notifications for:',
      '• ZF-Score Critical (>0.8): High volatility detected',
      '• Circuit Breaker: Trading halted for 30 minutes',
      '• Inflection Point: Momentum exhaustion (potential reversal)',
      '• Trade Executed: Confirmation when order filled',
      '• Profit/Loss Target: When TP or SL is hit',
    ],
    tips: [
      'Enable notifications in Settings for real-time alerts',
      'Alerts are ranked by priority (Critical > High > Medium)',
      'Check alert history in Settings to review past signals',
      'Customize alert preferences in Settings tab',
    ],
  },
  {
    title: 'Security Features',
    icon: '🔒',
    content: [
      'App includes advanced security:',
      '• AES-256 encryption for API keys and sensitive data',
      '• Anti-blocking: Randomized headers, rate limiting',
      '• Anti-manipulation: Data integrity hashing, anomaly detection',
      '• MITM detection: Certificate pinning and hash verification',
      '• Circuit breaker: Automatic halt on extreme conditions',
    ],
    tips: [
      'Data is encrypted locally on your device',
      'No personal data is sent to external servers',
      'All API calls use secure HTTPS connections',
      'Enable biometric authentication in Settings',
    ],
  },
  {
    title: 'Trading Best Practices',
    icon: '💡',
    content: [
      '1. Always use Stop-Loss (never trade without it)',
      '2. Risk only 1-2% of account per trade',
      '3. Combine ZF-Core signals with your own analysis',
      '4. Start with demo account to practice',
      '5. Keep trading journal to track performance',
      '6. Review past alerts to learn patterns',
    ],
    tips: [
      'ZF-Score is a tool, not a guarantee',
      'Market conditions change rapidly - stay alert',
      'Use multiple timeframes for confirmation',
      'Avoid trading during major economic events',
      'Manage emotions - stick to your trading plan',
    ],
  },
  {
    title: 'Troubleshooting',
    icon: '🔧',
    content: [
      'OCR not accurate: Ensure chart is clear, try different screenshot',
      'Broker connection fails: Check API credentials and internet',
      'No alerts received: Enable notifications in phone Settings',
      'App crashes: Clear cache and restart app',
      'Data not syncing: Check internet connection',
    ],
    tips: [
      'Contact support if issues persist',
      'Check app logs in Settings > Debug for error details',
      'Update app to latest version for bug fixes',
      'Report bugs to help us improve the app',
    ],
  },
];

export default function TutorialScreen() {
  const colors = useColors();
  const [expandedIndex, setExpandedIndex] = React.useState<number | null>(0);

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="mb-6">
          <Text className="text-4xl font-bold text-foreground mb-2">📚 How to Use</Text>
          <Text className="text-base text-muted">
            Complete guide to Forex ZF-Core Analyzer
          </Text>
        </View>

        {/* Tutorial Sections */}
        <View className="gap-3">
          {TUTORIAL_SECTIONS.map((section, index) => (
            <TutorialCard
              key={index}
              section={section}
              isExpanded={expandedIndex === index}
              onPress={() => setExpandedIndex(expandedIndex === index ? null : index)}
              colors={colors}
            />
          ))}
        </View>

        {/* Footer */}
        <View className="mt-8 p-4 bg-surface rounded-lg border border-border">
          <Text className="text-sm text-muted mb-3">
            For more help, visit our documentation or contact support
          </Text>
          <TouchableOpacity
            onPress={() => Linking.openURL('https://help.manus.im')}
            className="bg-primary px-4 py-2 rounded-lg"
          >
            <Text className="text-background font-semibold text-center">Contact Support</Text>
          </TouchableOpacity>
        </View>

        {/* Spacer */}
        <View className="h-20" />
      </ScrollView>
    </ScreenContainer>
  );
}

/**
 * Tutorial Card Component
 */
function TutorialCard({
  section,
  isExpanded,
  onPress,
  colors,
}: {
  section: TutorialSection;
  isExpanded: boolean;
  onPress: () => void;
  colors: any;
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      className="bg-surface rounded-lg border border-border overflow-hidden"
    >
      {/* Header */}
      <View className="flex-row items-center justify-between p-4 bg-surface">
        <View className="flex-row items-center gap-3 flex-1">
          <Text className="text-2xl">{section.icon}</Text>
          <View className="flex-1">
            <Text className="text-lg font-semibold text-foreground">{section.title}</Text>
          </View>
        </View>
        <Text className="text-xl text-muted">{isExpanded ? '−' : '+'}</Text>
      </View>

      {/* Content */}
      {isExpanded && (
        <View className="px-4 pb-4 border-t border-border pt-4">
          {/* Main Content */}
          <View className="gap-2 mb-4">
            {section.content.map((line, idx) => (
              <Text key={idx} className="text-sm text-foreground leading-relaxed">
                {line}
              </Text>
            ))}
          </View>

          {/* Tips */}
          {section.tips && section.tips.length > 0 && (
            <View className="bg-primary/10 p-3 rounded-lg border border-primary/20">
              <Text className="text-xs font-semibold text-primary mb-2">💡 Tips:</Text>
              {section.tips.map((tip, idx) => (
                <Text key={idx} className="text-xs text-foreground mb-1">
                  • {tip}
                </Text>
              ))}
            </View>
          )}
        </View>
      )}
    </TouchableOpacity>
  );
}

import * as React from 'react';
