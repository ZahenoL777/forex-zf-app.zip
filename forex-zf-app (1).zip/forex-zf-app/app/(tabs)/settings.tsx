import { ScrollView, Text, View, Pressable, Switch } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import { useState } from 'react';

/**
 * Settings Screen - Preferences & Security
 * 
 * Features:
 * - Theme selection (light/dark)
 * - Security settings (anti-blocking, anti-manipulation)
 * - Data validation options
 * - Notification preferences
 * - App information
 */

export default function SettingsScreen() {
  const colors = useColors();
  const [settings, setSettings] = useState({
    darkMode: true,
    antiBlocking: true,
    antiManipulation: true,
    dataValidation: true,
    notifications: true,
    encryptionEnabled: true,
    certificatePinning: true,
    rateLimit: true,
  });

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleClearCache = () => {
    // Clear app cache
    console.log('Cache cleared');
  };

  const handleExportData = () => {
    // Export analysis history
    console.log('Data exported');
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-6 pb-8">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Settings</Text>
            <Text className="text-sm text-muted">Preferences & security options</Text>
          </View>

          {/* Display Settings */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Display</Text>

            <View className="bg-surface rounded-lg p-4 border border-border flex-row justify-between items-center">
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Dark Mode</Text>
                <Text className="text-xs text-muted mt-1">Reduce eye strain</Text>
              </View>
              <Switch
                value={settings.darkMode}
                onValueChange={() => toggleSetting('darkMode')}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={settings.darkMode ? colors.success : colors.muted}
              />
            </View>
          </View>

          {/* Security Settings */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Security & Protection</Text>

            <View className="bg-surface rounded-lg p-4 border border-border gap-3">
              {/* Anti-Blocking */}
              <View className="flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Anti-Blocking</Text>
                  <Text className="text-xs text-muted mt-1">Bypass network restrictions</Text>
                </View>
                <Switch
                  value={settings.antiBlocking}
                  onValueChange={() => toggleSetting('antiBlocking')}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={settings.antiBlocking ? colors.success : colors.muted}
                />
              </View>

              <View className="h-px bg-border" />

              {/* Anti-Manipulation */}
              <View className="flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Anti-Manipulation</Text>
                  <Text className="text-xs text-muted mt-1">Detect tampered data</Text>
                </View>
                <Switch
                  value={settings.antiManipulation}
                  onValueChange={() => toggleSetting('antiManipulation')}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={settings.antiManipulation ? colors.success : colors.muted}
                />
              </View>

              <View className="h-px bg-border" />

              {/* Data Validation */}
              <View className="flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Data Validation</Text>
                  <Text className="text-xs text-muted mt-1">Validate against historical</Text>
                </View>
                <Switch
                  value={settings.dataValidation}
                  onValueChange={() => toggleSetting('dataValidation')}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={settings.dataValidation ? colors.success : colors.muted}
                />
              </View>

              <View className="h-px bg-border" />

              {/* Encryption */}
              <View className="flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">AES-256 Encryption</Text>
                  <Text className="text-xs text-muted mt-1">Encrypt sensitive data</Text>
                </View>
                <Switch
                  value={settings.encryptionEnabled}
                  onValueChange={() => toggleSetting('encryptionEnabled')}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={settings.encryptionEnabled ? colors.success : colors.muted}
                />
              </View>

              <View className="h-px bg-border" />

              {/* Certificate Pinning */}
              <View className="flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Certificate Pinning</Text>
                  <Text className="text-xs text-muted mt-1">HTTPS validation</Text>
                </View>
                <Switch
                  value={settings.certificatePinning}
                  onValueChange={() => toggleSetting('certificatePinning')}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={settings.certificatePinning ? colors.success : colors.muted}
                />
              </View>

              <View className="h-px bg-border" />

              {/* Rate Limiting */}
              <View className="flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Rate Limiting</Text>
                  <Text className="text-xs text-muted mt-1">Prevent detection</Text>
                </View>
                <Switch
                  value={settings.rateLimit}
                  onValueChange={() => toggleSetting('rateLimit')}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={settings.rateLimit ? colors.success : colors.muted}
                />
              </View>
            </View>
          </View>

          {/* Notifications */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Notifications</Text>

            <View className="bg-surface rounded-lg p-4 border border-border flex-row justify-between items-center">
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Push Notifications</Text>
                <Text className="text-xs text-muted mt-1">Get alerts for critical signals</Text>
              </View>
              <Switch
                value={settings.notifications}
                onValueChange={() => toggleSetting('notifications')}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={settings.notifications ? colors.success : colors.muted}
              />
            </View>
          </View>

          {/* Data Management */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Data Management</Text>

            <Pressable
              onPress={handleExportData}
              className="bg-surface rounded-lg p-4 border border-border flex-row justify-between items-center active:opacity-70"
            >
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Export Data</Text>
                <Text className="text-xs text-muted mt-1">Save analysis history</Text>
              </View>
              <Text className="text-lg">→</Text>
            </Pressable>

            <Pressable
              onPress={handleClearCache}
              className="bg-surface rounded-lg p-4 border border-border flex-row justify-between items-center active:opacity-70"
            >
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Clear Cache</Text>
                <Text className="text-xs text-muted mt-1">Free up storage space</Text>
              </View>
              <Text className="text-lg">→</Text>
            </Pressable>
          </View>

          {/* About */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">About</Text>

            <View className="bg-surface rounded-lg p-4 border border-border gap-3">
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">App Version</Text>
                <Text className="text-sm font-semibold text-foreground">1.0.0</Text>
              </View>
              <View className="h-px bg-border" />
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Build Number</Text>
                <Text className="text-sm font-semibold text-foreground">20260610</Text>
              </View>
              <View className="h-px bg-border" />
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Framework</Text>
                <Text className="text-sm font-semibold text-foreground">Expo 54</Text>
              </View>
            </View>
          </View>

          {/* Security Info */}
          <View className="bg-success bg-opacity-10 rounded-lg p-4 border border-success border-opacity-30 gap-2">
            <Text className="font-semibold text-success">✓ All Security Features Active</Text>
            <Text className="text-xs text-success opacity-80">
              Your data is protected with military-grade encryption and advanced anti-manipulation detection.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
